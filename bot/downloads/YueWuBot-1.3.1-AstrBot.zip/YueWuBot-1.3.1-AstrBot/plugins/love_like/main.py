import json
import time
from pathlib import Path

ASSETS = Path(__file__).parent / "assets"
DB = ASSETS / "like.json"

REPLY_OK = "我给你点了十下哦，记得给我回。"
REPLY_DUP = "今天好像点过了哈，明天再点吧～"
REPLY_FAIL = "点赞没成功，等会儿再试试吧（%s）"
DAY = 24 * 3600

def _load():
    try:
        data = json.loads(DB.read_text("utf-8"))
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _save(data):
    ASSETS.mkdir(parents=True, exist_ok=True)
    DB.write_text(json.dumps(data, ensure_ascii=False), "utf-8")


def _norm(text):
    return (text or "").strip().strip(" \t\r\n!！。.~～?？,，、…·")


def on_startup(bot):
    print("[love_like] 爱点赞插件已加载")


async def on_message(ctx):
    if _norm(ctx.text) != "赞我":
        return False

    uid = str(ctx.user_id)
    if not uid:
        return False

    db = _load()
    rec = db.get(uid) or {}
    now = time.time()
    try:
        last = float(rec.get("last") or 0)
    except Exception:
        last = 0

    try:
        hours = float(ctx.cfg.get("cooldown_hours") or 24)
    except Exception:
        hours = 24.0
    if now - last < max(hours, 0.1) * 3600:
        await ctx.reply(REPLY_DUP)
        return True

    try:
        times = int(ctx.cfg.get("times") or 10)
    except Exception:
        times = 10

    try:
        resp = await ctx.api("send_like", user_id=int(uid), times=times)
    except Exception as exc:
        await ctx.reply(REPLY_FAIL % str(exc)[:60])
        return True

    ok = isinstance(resp, dict) and (
        str(resp.get("status") or "") in ("ok", "async") or str(resp.get("retcode")) == "0"
    )
    if not ok:
        why = ""
        if isinstance(resp, dict):
            why = resp.get("wording") or resp.get("message") or resp.get("retcode") or ""
        await ctx.reply(REPLY_FAIL % (str(why)[:60] or "平台没有回应"))
        return True

    db[uid] = {"last": now, "total": int(rec.get("total") or 0) + 1}
    _save(db)
    await ctx.reply(REPLY_OK)
    return True
