#!/usr/bin/env bash
set -euo pipefail

APP_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$APP_DIR"

NAME="yuewubot"
PORT="${YW_PORT:-6199}"
HOST="${YW_HOST:-127.0.0.1}"
VENV="$APP_DIR/.venv"
PIP_PAGES="${YW_PIP_PAGES:-https://chumianyi.github.io/pip/}"
PIP_USTC="https://pypi.mirrors.ustc.edu.cn/simple"
PIP_TUNA="${PIP_MIRROR:-https://pypi.tuna.tsinghua.edu.cn/simple}"
SERVICE="/etc/systemd/system/${NAME}.service"
LOGDIR="$APP_DIR/logs"
PWDFILE="$APP_DIR/.pid"
ACCEPTED="$APP_DIR/data/.disclaimer_accepted"

C_OK="\033[32m"; C_WARN="\033[33m"; C_ERR="\033[31m"; C_DIM="\033[2m"; C_END="\033[0m"
ok()   { printf "${C_OK}[OK]${C_END} %s\n" "$*"; }
warn() { printf "${C_WARN}!${C_END} %s\n" "$*"; }
err()  { printf "${C_ERR}[FAIL]${C_END} %s\n" "$*" >&2; }
dim()  { printf "${C_DIM}%s${C_END}\n" "$*"; }

find_python() {
  local c v
  for c in python3.9 python3.8 python3.7 python3.6 python3 python; do
    if command -v "$c" >/dev/null 2>&1; then
      v="$("$c" -c 'import sys; print("%d%02d" % sys.version_info[:2])' 2>/dev/null || echo 0)"
      if [ "${v:-0}" -ge 306 ]; then echo "$c"; return 0; fi
    fi
  done
  return 1
}

have_systemd() {
  command -v systemctl >/dev/null 2>&1 && [ -d /run/systemd/system ] && [ "$(id -u)" = "0" ]
}

need_python() {
  PY="$(find_python)" || {
    err "没有找到 Python 3.6+，请先安装：yum install -y python36 或 apt install -y python3"
    exit 1
  }
  dim "使用解释器：$(command -v "$PY")  $("$PY" -V 2>&1)"
}

detect_arch() {
  case "$(uname -m | tr '[:upper:]' '[:lower:]')" in
    x86_64|amd64)      echo "x86_64 / X64 / x86-x64 / AMD64" ;;
    aarch64|arm64)     echo "ARM64 / aarch64" ;;
    i386|i486|i586|i686) echo "X86 / i686 32-bit" ;;
    *)                 echo "$(uname -m) / universal" ;;
  esac
}

show_disclaimer() {
  cat <<'EOF'

==========================================================================
                        YueWuBot 免责声明
==========================================================================

本软件按"现状"提供，仅供学习与技术交流使用。继续使用即表示你已完整阅读、
理解并同意以下全部条款：

1. 本软件通过 OneBot v11 协议与第三方即时通讯平台对接，属于非官方客户端
   工具。使用第三方客户端或自动化机器人可能违反对应平台的服务条款，存在
   账号被限制、冻结或封禁的风险，该风险由使用者自行承担。

2. 使用者应确保自身行为符合所在地区法律法规及平台规则，不得将本软件用于
   发送垃圾信息、骚扰、诈骗、侵犯他人隐私或任何违法违规用途。

3. 本软件及作者不对因使用、误用或无法使用本软件所导致的任何直接或间接
   损失承担责任，包括但不限于账号、数据丢失与业务中断。

4. 本软件为开源软件，使用者可自行审阅全部源码；插件与模型接口由使用者
   自行配置，其产生的内容与后果由使用者负责。

==========================================================================
EOF
}

is_yes() {
  case "${1:-}" in
    [Yy]|[Yy][Ee][Ss]) return 0 ;;
  esac
  return 1
}

require_disclaimer() {
  if [ -f "$ACCEPTED" ]; then return 0; fi
  if is_yes "${YW_ACCEPT:-}"; then
    mkdir -p "$APP_DIR/data"
    printf 'accepted\n' > "$ACCEPTED"
    ok "免责声明已同意（YW_ACCEPT）"
    return 0
  fi
  show_disclaimer
  printf "\n请输入 Y 或 yes 同意并继续一键安装（不区分大小写，其他输入将取消）："
  if ! IFS= read -r _ans; then
    err "未能读取确认，非交互环境请先执行：YW_ACCEPT=Y ./start.sh"
    exit 1
  fi
  if is_yes "${_ans:-}"; then
    mkdir -p "$APP_DIR/data"
    printf 'accepted\n' > "$ACCEPTED"
    ok "免责声明已同意"
  else
    err "未同意免责声明，安装已取消"
    exit 1
  fi
}

ensure_venv() {
  if [ -x "$VENV/bin/python" ]; then return 0; fi
  ok "创建虚拟环境 .venv"
  if ! "$PY" -m venv "$VENV" >/dev/null 2>&1; then
    if ! "$PY" -m virtualenv "$VENV" >/dev/null 2>&1; then
      err "创建虚拟环境失败，请安装 python3-venv / python36-virtualenv 后重试"
      exit 1
    fi
  fi
}

pip_install() {
  local spec="$1"
  if "$VENV/bin/python" -m pip install -q --no-index --find-links "$PIP_PAGES" \
      --timeout 60 --disable-pip-version-check "$spec" >/dev/null 2>&1; then
    ok "依赖源：GitHub Pages 托管包（$(detect_arch)）"
    return 0
  fi
  warn "GitHub Pages 托管包安装失败，切换中科大源"
  if "$VENV/bin/python" -m pip install -q -i "$PIP_USTC" \
      --timeout 60 --disable-pip-version-check "$spec" >/dev/null 2>&1; then
    ok "依赖源：中科大源"
    return 0
  fi
  warn "中科大源安装失败，切换清华源"
  if "$VENV/bin/python" -m pip install -q -i "$PIP_TUNA" \
      --timeout 60 --disable-pip-version-check "$spec" >/dev/null 2>&1; then
    ok "依赖源：清华源"
    return 0
  fi
  return 1
}

ensure_deps() {
  if "$VENV/bin/python" -c "import aiohttp, sys; v = tuple(int(x) for x in aiohttp.__version__.split('.')[:2] if x.isdigit()); sys.exit(0 if v >= (3, 4) else 1)" >/dev/null 2>&1; then
    ok "依赖已就绪 aiohttp"
    return 0
  fi
  ok "安装依赖（aiohttp）"
  dim "当前架构：$(detect_arch)"
  dim "源顺序：GitHub Pages -> 中科大 -> 清华"
  pip_install "pip<22" || warn "pip 升级失败，继续尝试安装依赖"
  if ! pip_install "aiohttp>=3.4,<4"; then
    err "三个依赖源均安装失败，请检查网络，或手动执行：$VENV/bin/pip install aiohttp"
    exit 1
  fi
  ok "依赖安装完成"
}

write_service() {
  need_python
  cat > "$SERVICE" <<EOF
[Unit]
Description=YueWuBot QQ Bot
After=network.target

[Service]
Type=simple
WorkingDirectory=$APP_DIR
Environment=YW_HOST=$HOST
Environment=YW_PORT=$PORT
Environment=PYTHONUNBUFFERED=1
ExecStart=$VENV/bin/python $APP_DIR/yuewubot.py
Restart=always
RestartSec=3
LimitNOFILE=65535
MemoryLimit=300M
CPUQuota=80%
CPUAccounting=yes

[Install]
WantedBy=multi-user.target
EOF
  systemctl daemon-reload
}

port_busy() {
  (command -v ss >/dev/null 2>&1 && ss -lnt 2>/dev/null | grep -q ":$PORT ") && return 0
  (command -v netstat >/dev/null 2>&1 && netstat -lnt 2>/dev/null | grep -q ":$PORT ") && return 0
  return 1
}

show_token() {
  local tk=""
  for _ in 1 2 3 4 5 6 7 8 9 10; do
    if [ -f "$APP_DIR/data/config.json" ]; then
      tk="$("$VENV/bin/python" - "$APP_DIR/data/config.json" <<'PY' 2>/dev/null || true
import json, sys
try:
    print(json.load(open(sys.argv[1])).get("token") or "")
except Exception:
    print("")
PY
)"
      [ -n "$tk" ] && break
    fi
    sleep 1
  done
  echo
  echo "  控制台  http://127.0.0.1:$PORT"
  if [ -n "$tk" ]; then
    echo "  令牌    $tk"
  else
    warn "配置尚未生成，稍后执行 ./start.sh token 查看"
  fi
  echo
}

start_systemd() {
  need_python; ensure_venv; ensure_deps; mkdir -p "$LOGDIR"
  write_service
  systemctl enable "$NAME" >/dev/null 2>&1 || true
  systemctl restart "$NAME"
  sleep 1
  if systemctl is-active --quiet "$NAME"; then
    ok "服务已启动（systemd: $NAME）"
  else
    err "服务启动失败，查看日志：journalctl -u $NAME -n 50 --no-pager"
    exit 1
  fi
  show_token
}

start_plain() {
  need_python; ensure_venv; ensure_deps; mkdir -p "$LOGDIR"
  if [ -f "$PWDFILE" ] && kill -0 "$(cat "$PWDFILE")" 2>/dev/null; then
    warn "已在运行（PID $(cat "$PWDFILE")），如需重启请执行 ./start.sh restart"
    return 0
  fi
  if port_busy; then
    err "端口 $PORT 已被占用，可用 YW_PORT=其他端口 ./start.sh"
    exit 1
  fi
  YW_HOST="$HOST" YW_PORT="$PORT" nohup "$VENV/bin/python" "$APP_DIR/yuewubot.py" >> "$LOGDIR/app.log" 2>&1 &
  echo $! > "$PWDFILE"
  sleep 2
  if kill -0 "$(cat "$PWDFILE")" 2>/dev/null; then
    ok "已在后台启动（PID $(cat "$PWDFILE")）"
  else
    err "启动失败，查看 $LOGDIR/app.log"
    tail -n 20 "$LOGDIR/app.log" 2>/dev/null || true
    exit 1
  fi
  show_token
}

cmd_start() {
  require_disclaimer
  if have_systemd; then start_systemd; else start_plain; fi
}

cmd_stop() {
  if have_systemd && [ -f "$SERVICE" ]; then
    systemctl stop "$NAME" 2>/dev/null || true
    ok "已停止（systemd）"
  else
    if [ -f "$PWDFILE" ] && kill -0 "$(cat "$PWDFILE")" 2>/dev/null; then
      kill "$(cat "$PWDFILE")" 2>/dev/null || true
      sleep 1
      ok "已停止"
    else
      warn "没有在运行的进程"
    fi
    rm -f "$PWDFILE"
  fi
}

cmd_status() {
  if have_systemd && [ -f "$SERVICE" ]; then
    systemctl status "$NAME" --no-pager -l | head -n 12 || true
  fi
  if [ -f "$PWDFILE" ] && kill -0 "$(cat "$PWDFILE")" 2>/dev/null; then
    ok "运行中 PID $(cat "$PWDFILE")"
  else
    if have_systemd && [ -f "$SERVICE" ] && systemctl is-active --quiet "$NAME"; then
      :
    else
      warn "未运行"
    fi
  fi
  if port_busy; then dim "端口 $PORT 正在监听"; fi
}

cmd_foreground() {
  require_disclaimer
  need_python; ensure_venv; ensure_deps; mkdir -p "$LOGDIR"
  ok "前台运行，按 Ctrl+C 退出"
  YW_HOST="$HOST" YW_PORT="$PORT" exec "$VENV/bin/python" "$APP_DIR/yuewubot.py"
}

cmd_logs() {
  if have_systemd && [ -f "$SERVICE" ]; then
    journalctl -u "$NAME" -f -n 60 --no-pager
  else
    tail -f "$LOGDIR/app.log"
  fi
}

cmd_token() {
  if [ ! -f "$APP_DIR/data/config.json" ]; then
    err "还没有配置文件，先执行 ./start.sh"
    exit 1
  fi
  "$VENV/bin/python" - "$APP_DIR/data/config.json" <<'PY'
import json, sys
d = json.load(open(sys.argv[1]))
print(d.get("token") or "")
PY
}

cmd_uninstall() {
  cmd_stop
  if have_systemd && [ -f "$SERVICE" ]; then
    systemctl disable "$NAME" >/dev/null 2>&1 || true
    rm -f "$SERVICE"
    systemctl daemon-reload
    ok "已移除 systemd 服务"
  fi
  echo
  warn "以下内容未删除，确认无用后自行处理："
  dim "  $VENV   依赖环境"
  dim "  $APP_DIR/data   配置与令牌"
  dim "  $APP_DIR/plugins   已装插件"
}

usage() {
  cat <<'EOF'
YueWuBot v1.3.1 部署脚本

执行第 1 步需阅读并同意免责声明，输入 Y 或 yes 即同意（不区分大小写），随后自动完成一键安装。
同意状态会记录，后续执行不再重复询问。

  ./start.sh              同意免责声明后一键安装并启动
  ./start.sh fg           安装依赖并前台运行（调试用，Ctrl+C 退出）
  ./start.sh stop         停止
  ./start.sh restart      重启
  ./start.sh status       运行状态
  ./start.sh logs         查看实时日志
  ./start.sh token        查看控制台登录令牌
  ./start.sh uninstall    卸载服务（保留数据）

依赖源顺序（自动降级）：
  1  GitHub Pages 托管包   https://chumianyi.github.io/pip/
  2  中科大源              https://pypi.mirrors.ustc.edu.cn/simple
  3  清华源                https://pypi.tuna.tsinghua.edu.cn/simple

托管包覆盖 x86_64 / X64 / x86-x64 / AMD64、ARM64 / aarch64、X86 / i686，
并附带平台无关的源码包与纯 Python 包，可覆盖其他架构与 Python 3.6+ 版本。

环境变量：
  YW_ACCEPT=Y            非交互同意（也接受 y / yes / YES 等任意大小写）
  YW_PIP_PAGES=...       自定义 GitHub Pages 托管包地址
  PIP_MIRROR=...         自定义第三级备用镜像源
  YW_PORT=6199           监听端口
  YW_HOST=127.0.0.1      监听地址，对外暴露可设 0.0.0.0
EOF
}

case "${1:-start}" in
  start)     cmd_start ;;
  fg|foreground|run) cmd_foreground ;;
  stop)      cmd_stop ;;
  restart)   cmd_stop; sleep 1; cmd_start ;;
  status)    cmd_status ;;
  logs)      cmd_logs ;;
  token)     cmd_token ;;
  uninstall) cmd_uninstall ;;
  *)         usage ;;
esac
