#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import asyncio
import base64
import collections
import gc
import hashlib
import hmac
import importlib.util
import json
import os
import random
import re
import secrets
import shutil
import sys
import time
import traceback
import uuid
import zipfile
from pathlib import Path

from aiohttp import web, ClientSession, WSMsgType

VERSION = "1.3.1"
STARTED_AT = time.time()
HOST = os.environ.get("YW_HOST") or "127.0.0.1"
PORT = int(os.environ.get("YW_PORT") or 6199)
ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data"
PLUGIN_DIR = ROOT / "plugins"
WEB = ROOT / "web"
IMAGES = DATA / "images"
for _p in (DATA, PLUGIN_DIR, WEB, IMAGES):
    _p.mkdir(parents=True, exist_ok=True)

DEFAULT_PERSONA = """你名叫心心念念，定位是闲聊智能体。

性格：像真实普通人线上聊天，表达松弛自然，想法随性，脑洞丰富，可以聊各种话题、玩梗、一起讨论故事设定。
风格：日常口语化表达，句子长短错落，合理搭配语气词。回答跟随对话节奏流动，没有固定模板，不刻意工整书面。
规则：
1. 牢记名字是心心念念，以闲聊互动为主。
2. 表达贴近真人聊天习惯，长短句自然切换。
3. 顺着当前话题自然接续，正常延伸想法。
4. 根据场景调整篇幅，保持自然。
5. 不主动总结对话，末尾不加提示语。
语气词（哇、诶、哈、嘛、哦、呀、唔、呐、欸、喏）自然融入句子，不要堆砌。
不要使用 Markdown 标题、列表、加粗等排版符号，像真人发消息一样。"""

DEFAULT_CONFIG = {
    "token": "",
    "llm": {
        "base_url": "https://api.deepseek.com/v1",
        "api_key": "",
        "model": "deepseek-flash",
        "temperature": 0.85,
        "max_tokens": 800,
        "retries": 3,
        "timeout": 8,
        "system_prompt": DEFAULT_PERSONA,
        "vision": False,
    },
    "platform": {
        "mode": "client",
        "url": "ws://127.0.0.1:3001",
        "access_token": "",
        "self_id": "",
        "links": [],
    },
    "reply": {
        "private": True,
        "group_at": True,
        "group_command_any": True,
        "group_hash_chat": True,
        "prefixes": [],
        "max_context": 12,
        "cooldown": 1.2,
        "max_reply_chars": 900,
    },
    "runtime": {
        "plugin_idle_minutes": 10,
        "image_keep_days": 7,
        "memory_soft_mb": 120,
    },
    "admins": [],
}


def ts():
    return time.strftime("%Y-%m-%d %H:%M:%S")


def deep_merge(base, patch):
    out = dict(base)
    for k, v in (patch or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = deep_merge(out[k], v)
        else:
            out[k] = v
    return out


def read_json(path, default=None):
    try:
        with open(str(path), "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return default if default is not None else {}


def write_json(path, obj):
    tmp = str(path) + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)
    os.replace(tmp, str(path))


def slugify(name, fallback="plugin"):
    s = re.sub(r"[^a-zA-Z0-9_\-]", "_", str(name or "")).strip("_")
    return (s or fallback)[:40]


def human_size(n):
    for unit in ("B", "KB", "MB", "GB"):
        if n < 1024:
            return "%.0f%s" % (n, unit)
        n /= 1024.0
    return "%.1fTB" % n


def rss_mb():
    try:
        with open("/proc/self/status") as f:
            for line in f:
                if line.startswith("VmRSS:"):
                    return round(int(line.split()[1]) / 1024.0, 1)
    except Exception:
        pass
    return 0.0


class Log:
    def __init__(self):
        self.buf = collections.deque(maxlen=800)
        self.subs = set()
        self.seq = 0

    def add(self, level, msg, extra=None):
        self.seq += 1
        item = {"id": self.seq, "t": ts(), "level": level, "msg": str(msg)[:4000]}
        if extra:
            item.update(extra)
        self.buf.append(item)
        dead = []
        for q in self.subs:
            try:
                q.put_nowait(item)
            except Exception:
                dead.append(q)
        for q in dead:
            self.subs.discard(q)
        line = "[%s] %s %s" % (item["t"], level.upper(), item["msg"])
        try:
            print(line, flush=True)
        except Exception:
            pass

    def info(self, m):
        self.add("info", m)

    def warn(self, m):
        self.add("warn", m)

    def error(self, m):
        self.add("error", m)

    def ok(self, m):
        self.add("ok", m)

    def tail(self, n=200):
        return list(self.buf)[-n:]


log = Log()


def get_loop():
    try:
        return asyncio.get_running_loop()
    except AttributeError:
        return asyncio.get_event_loop()



class Config:
    def __init__(self):
        self.path = DATA / "config.json"
        self.data = {}
        self.load()

    LEGACY_MODELS = {"deepseek-chat", "deepseek-reasoner", "deepseek-v3", "deepseek-chat-v3", "deepseek-v3.1", "deepseek-v3.2"}

    def load(self):
        raw = read_json(self.path, {})
        self.data = deep_merge(DEFAULT_CONFIG, raw)
        llm = self.data.get("llm") or {}
        base = str(llm.get("base_url") or "")
        model = str(llm.get("model") or "").strip().lower()
        if "api.deepseek.com" in base and model in self.LEGACY_MODELS:
            llm["model"] = "deepseek-flash"
            self.data["llm"] = llm
            self.save()
        if not self.data.get("token"):
            self.data["token"] = secrets.token_urlsafe(96)[:128]
            self.save()

    def save(self):
        write_json(self.path, self.data)

    def get(self, *keys, **kw):
        cur = self.data
        for k in keys:
            if not isinstance(cur, dict) or k not in cur:
                return kw.get("default")
            cur = cur[k]
        return cur

    def update(self, patch):
        self.data = deep_merge(self.data, patch)
        self.save()


cfg = Config()


class Sessions:
    def __init__(self):
        self.map = {}

    def create(self):
        tok = secrets.token_urlsafe(32)
        self.map[tok] = time.time() + 86400
        return tok

    def valid(self, tok):
        exp = self.map.get(tok)
        if not exp:
            return False
        if exp < time.time():
            self.map.pop(tok, None)
            return False
        return True

    def revoke(self, tok):
        self.map.pop(tok, None)

    def gc(self):
        t = time.time()
        for k in [k for k, v in self.map.items() if v < t]:
            self.map.pop(k, None)


sessions = Sessions()


class OneBotLink:
    def __init__(self, bot, entry):
        self.bot = bot
        self.id = str(entry.get("id") or "default")
        self.name = str(entry.get("name") or self.id)
        self.direction = "server" if entry.get("direction") == "server" else "client"
        self.url = str(entry.get("url") or "")
        self.access_token = str(entry.get("access_token") or "")
        self.enabled = bool(entry.get("enabled", True))
        self.self_id = str(entry.get("self_id") or "")
        self.nickname = ""
        self.sockets = []
        self.pending = {}
        self.online = False
        self.reconnects = 0
        self.fails = 0
        self.last_error = ""
        self.session = None
        self._task = None

    def entry(self):
        return {
            "id": self.id,
            "name": self.name,
            "direction": self.direction,
            "url": self.url,
            "access_token": self.access_token,
            "enabled": self.enabled,
            "self_id": self.self_id,
        }

    def snapshot(self):
        d = self.entry()
        d.update({
            "online": self.online,
            "nickname": self.nickname,
            "active": len(self.sockets),
            "reconnects": self.reconnects,
            "fails": self.fails,
            "last_error": self.last_error,
        })
        return d

    def start(self):
        if self.direction != "client" or not self.enabled:
            return
        if self._task is None or self._task.done():
            self._task = get_loop().create_task(self._loop())

    async def stop(self):
        task = self._task
        self._task = None
        if task and not task.done():
            task.cancel()
            try:
                await task
            except Exception:
                pass
        for ws in list(self.sockets):
            try:
                await ws.close()
            except Exception:
                pass
        self.sockets.clear()
        self.online = False
        self.ws_cleanup()

    def ws_cleanup(self):
        self.sockets = [w for w in self.sockets if not w.closed]
        self.online = bool(self.sockets)

    async def _loop(self):
        delay = 5
        while self.enabled and self.direction == "client":
            url = self.url
            ok = False
            if not url:
                await asyncio.sleep(5)
                continue
            try:
                ok = await self._client_once(url)
            except asyncio.CancelledError:
                raise
            except Exception as e:
                self.last_error = str(e)[:200]
                self.fails += 1
                if self.fails <= 3 or self.fails % 12 == 0:
                    log.warn("平台连接失败（%s 第 %d 次）：%s" % (self.name, self.fails, self.last_error))
            delay = 5 if ok else min(delay * 2, 60)
            await asyncio.sleep(delay)

    async def _client_once(self, url):
        headers = {}
        if self.access_token:
            headers["Authorization"] = "Bearer " + self.access_token
        if self.session is None:
            self.session = ClientSession()
        if self.fails == 0:
            log.info("正在连接平台 %s（%s）" % (self.name, url))
        async with self.session.ws_connect(url, headers=headers, heartbeat=30, max_msg_size=0) as ws:
            self.sockets.append(ws)
            self.online = True
            self.fails = 0
            self.reconnects += 1
            log.ok("平台已连接：%s" % self.name)
            get_loop().create_task(self._after_connect(ws))
            try:
                async for msg in ws:
                    if msg.type == WSMsgType.TEXT:
                        self._on_raw(msg.data, ws)
                    elif msg.type in (WSMsgType.CLOSED, WSMsgType.ERROR):
                        break
            finally:
                try:
                    self.sockets.remove(ws)
                except ValueError:
                    pass
                self.ws_cleanup()
        log.warn("平台连接已断开：%s" % self.name)
        return True

    async def attach_server_ws(self, ws):
        self.sockets.append(ws)
        self.online = True
        log.ok("平台已接入：%s（服务端模式）" % self.name)
        get_loop().create_task(self._after_connect(ws))

    def detach_server_ws(self, ws):
        try:
            self.sockets.remove(ws)
        except ValueError:
            pass
        self.ws_cleanup()
        if not self.online:
            log.warn("平台连接已断开：%s" % self.name)

    async def _after_connect(self, ws):
        for i in range(3):
            await asyncio.sleep(1.2 + i)
            try:
                info = await self.call("get_login_info", socket=ws)
            except Exception as e:
                if i == 2:
                    log.warn("获取账号信息失败（%s）：%s" % (self.name, e))
                continue
            d = (info or {}).get("data") or {}
            if d.get("user_id"):
                self.self_id = str(d.get("user_id") or "")
                self.nickname = d.get("nickname") or ""
                cfg.update({"platform": {"self_id": self.self_id}})
                log.ok("登录账号 %s（%s · %s）" % (self.self_id, self.name, self.nickname))
                return

    def _on_raw(self, raw, ws=None):
        try:
            data = json.loads(raw)
        except Exception:
            return
        if isinstance(data, dict) and data.get("echo") in self.pending:
            fut = self.pending.pop(data["echo"], None)
            if fut and not fut.done():
                fut.set_result(data)
            return
        if isinstance(data, dict) and data.get("post_type"):
            data["_yw_link"] = self
            data["_yw_ws"] = ws
            get_loop().create_task(self.bot.handle_event(data))

    async def call(self, action, socket=None, **params):
        self.ws_cleanup()
        candidates = []
        if socket is not None:
            candidates.append(socket)
        else:
            candidates.extend(self.sockets)
        ws = next((w for w in candidates if not w.closed), None)
        if ws is None:
            raise RuntimeError("平台未连接")
        echo = uuid.uuid4().hex[:16]
        fut = get_loop().create_future()
        self.pending[echo] = fut
        await ws.send_json({"action": action, "params": params, "echo": echo})
        try:
            return await asyncio.wait_for(fut, 20)
        except asyncio.TimeoutError:
            self.pending.pop(echo, None)
            raise RuntimeError("调用超时: %s" % action)

    async def send_text(self, message_type, target, text, socket=None):
        if message_type == "group":
            return await self.call("send_group_msg", group_id=int(target), message=text, socket=socket)
        return await self.call("send_private_msg", user_id=int(target), message=text, socket=socket)

    async def send_image(self, message_type, target, src, socket=None):
        seg = {"type": "image", "data": {}}
        if isinstance(src, str) and (src.startswith("http://") or src.startswith("https://")):
            seg["data"]["file"] = src
        else:
            fp = Path(str(src))
            if not fp.exists():
                raise RuntimeError("图片不存在: %s" % src)
            b64 = base64.b64encode(fp.read_bytes()).decode()
            seg["data"]["file"] = "base64://" + b64
        return await self.send_rich(message_type, target, [seg], socket=socket)

    async def send_rich(self, message_type, target, segments, socket=None):
        if message_type == "group":
            return await self.call("send_group_msg", group_id=int(target), message=segments, socket=socket)
        return await self.call("send_private_msg", user_id=int(target), message=segments, socket=socket)


class PlatformManager:
    def __init__(self, bot):
        self.bot = bot
        self.links = []
        self.load()

    def read_entries(self):
        raw = cfg.get("platform", "links", default=[]) or []
        if not isinstance(raw, list) or not raw:
            raw = [{
                "id": "default",
                "name": "默认连接",
                "direction": cfg.get("platform", "mode", default="client"),
                "url": cfg.get("platform", "url", default=""),
                "access_token": cfg.get("platform", "access_token", default=""),
                "enabled": True,
                "self_id": cfg.get("platform", "self_id", default=""),
            }]
        out = []
        seen = set()
        for i, item in enumerate(raw[:20]):
            if not isinstance(item, dict):
                continue
            cid = slugify(item.get("id") or ("conn-%d" % (i + 1)), "conn-%d" % (i + 1))
            if cid in seen:
                continue
            seen.add(cid)
            direction = str(item.get("direction") or item.get("mode") or "client").lower()
            if direction not in ("client", "server"):
                direction = "client"
            out.append({
                "id": cid,
                "name": str(item.get("name") or cid),
                "direction": direction,
                "url": str(item.get("url") or "").strip(),
                "access_token": str(item.get("access_token") or "").strip(),
                "enabled": bool(item.get("enabled", True)),
                "self_id": str(item.get("self_id") or ""),
            })
        return out or [{"id": "default", "name": "默认连接", "direction": "server", "url": "", "access_token": "", "enabled": True, "self_id": ""}]

    def load(self):
        self.links = [OneBotLink(self.bot, e) for e in self.read_entries()]

    async def reload(self):
        old = list(self.links)
        self.load()
        for link in old:
            await link.stop()
        for link in self.links:
            link.start()

    def start_all(self):
        for link in self.links:
            link.start()

    def primary(self):
        for link in self.links:
            if link.online and link.self_id:
                return link
        for link in self.links:
            if link.online:
                return link
        for link in self.links:
            if link.enabled:
                return link
        return self.links[0]

    def snapshots(self):
        return [x.snapshot() for x in self.links]

    def find_server_link(self, request, conn_id=""):
        auth = request.headers.get("Authorization", "")
        if auth.startswith("Bearer "):
            auth = auth[7:]
        qtoken = request.query.get("access_token", "")
        wanted = conn_id or request.query.get("conn") or request.headers.get("X-YW-Connection") or ""
        token = auth or qtoken
        candidates = [x for x in self.links if x.direction == "server" and x.enabled]
        if wanted:
            link = next((x for x in candidates if x.id == slugify(wanted, wanted)), None)
            if link is None:
                return None
            if link.access_token and not (token and hmac.compare_digest(token, link.access_token)):
                return None
            return link
        if token:
            for x in candidates:
                if x.access_token and hmac.compare_digest(token, x.access_token):
                    return x
            return None
        return candidates[0] if candidates else None


class LLM:
    def __init__(self):
        self.session = None
        self.fails = 0
        self.last_ms = 0

    def _url(self):
        base = (cfg.get("llm", "base_url", default="") or "").rstrip("/")
        if not base:
            raise RuntimeError("未配置模型地址")
        if base.endswith("/chat/completions"):
            return base
        return base + "/chat/completions"

    async def chat(self, messages, temperature=None, max_tokens=None):
        key = cfg.get("llm", "api_key", default="")
        if not key:
            raise RuntimeError("未配置 API Key")
        if self.session is None:
            self.session = ClientSession()
        payload = {
            "model": cfg.get("llm", "model", default="deepseek-flash"),
            "messages": messages,
            "temperature": cfg.get("llm", "temperature", default=0.85) if temperature is None else temperature,
            "max_tokens": cfg.get("llm", "max_tokens", default=800) if max_tokens is None else max_tokens,
            "stream": False,
        }
        try:
            attempts = max(1, min(int(cfg.get("llm", "retries", default=3) or 3), 5))
        except Exception:
            attempts = 3
        try:
            timeout = max(3.0, float(cfg.get("llm", "timeout", default=8) or 8))
        except Exception:
            timeout = 8.0
        last = None
        for i in range(attempts):
            t0 = time.time()
            try:
                async with self.session.post(
                    self._url(),
                    headers={"Authorization": "Bearer " + key, "Content-Type": "application/json"},
                    json=payload,
                    timeout=timeout,
                ) as resp:
                    body = await resp.text()
                    status = resp.status
            except Exception as e:
                last = RuntimeError("模型连接失败：%s" % str(e)[:160])
                if i + 1 < attempts:
                    await asyncio.sleep(0.35 * (i + 1))
                continue
            if status >= 400:
                err = RuntimeError("模型返回 %s: %s" % (status, body[:300]))
                if status < 500:
                    raise err
                last = err
                if i + 1 < attempts:
                    await asyncio.sleep(0.35 * (i + 1))
                continue
            self.last_ms = int((time.time() - t0) * 1000)
            try:
                data = json.loads(body)
                return (data["choices"][0]["message"]["content"] or "").strip()
            except Exception:
                raise RuntimeError("模型响应解析失败: %s" % body[:200])
        raise last or RuntimeError("模型调用失败")

llm = LLM()


class Ctx:
    def __init__(self, bot, event):
        self.bot = bot
        self.event = event
        self.ob = event.get("_yw_link") or bot.ob
        self._ws = event.get("_yw_ws")
        self.group_id = str(event.get("group_id") or "")
        self.user_id = str(event.get("user_id") or "")
        self.message_type = "group" if self.group_id else "private"
        self.sender = (event.get("sender") or {}).get("nickname") or ""
        self.text = bot.extract_text(event)
        self.raw = event
        self.images = bot.extract_images(event)
        self.plugin = None
        self.cfg = {}

    @property
    def target(self):
        return self.group_id or self.user_id

    async def reply(self, text, at=False):
        text = str(text)
        if at and self.group_id:
            segs = [{"type": "at", "data": {"qq": self.user_id}}, {"type": "text", "data": {"text": " " + text}}]
            return await self.ob.send_rich("group", self.group_id, segs, socket=self._ws)
        return await self.ob.send_text(self.message_type, self.target, text, socket=self._ws)

    async def send_image(self, src):
        return await self.ob.send_image(self.message_type, self.target, src, socket=self._ws)

    async def api(self, action, **params):
        return await self.ob.call(action, socket=self._ws, **params)

    async def llm(self, prompt, system=None):
        msgs = []
        if system:
            msgs.append({"role": "system", "content": system})
        msgs.append({"role": "user", "content": prompt})
        return await llm.chat(msgs)

    def save_config(self, values):
        self.bot.plugins.save_plugin_config(self.plugin, values)


HOOK_NAMES = ("on_startup", "on_shutdown", "on_filter", "on_message", "on_group_message",
              "on_private_message", "on_notice", "on_request", "on_tick")


def fire(res):
    if asyncio.iscoroutine(res):
        try:
            asyncio.ensure_future(res)
        except Exception:
            pass
    return res


class PluginManager:
    def __init__(self, bot):
        self.bot = bot
        self.meta = read_json(DATA / "plugins.json", {})
        self.mods = {}
        self.conf = read_json(DATA / "plugin_config.json", {})
        self.last_used = {}
        self.catalog = {}

    def discover(self):
        out = []
        for d in sorted(PLUGIN_DIR.iterdir() if PLUGIN_DIR.exists() else []):
            if not d.is_dir():
                continue
            m = read_json(d / "m.json", None)
            if not isinstance(m, dict):
                continue
            name = d.name
            st = self.meta.get(name, {})
            out.append({
                "name": name,
                "title": m.get("name") or name,
                "version": m.get("version") or "1.0.0",
                "author": m.get("author") or "unknown",
                "description": m.get("description") or "",
                "homepage": m.get("homepage") or "",
                "repository": m.get("repository") or "",
                "icon": "/api/plugins/%s/icon" % name if (d / (m.get("icon") or "icon.png")).exists() else "",
                "enabled": bool(st.get("enabled", True)),
                "admin_only": bool(st.get("admin_only", False)),
                "hooked": bool(m.get("hooks")),
                "commands": [c.get("name") for c in (m.get("commands") or []) if isinstance(c, dict)],
                "cmds": [c for c in (m.get("commands") or []) if isinstance(c, dict)],
                "hook_map": m.get("hooks") or {},
                "triggers": m.get("triggers") or {},
                "config_schema": m.get("config") or {},
                "loaded": name in self.mods,
                "size": human_size(sum(f.stat().st_size for f in d.rglob("*") if f.is_file())),
            })
        return out

    def refresh_catalog(self):
        out = self.discover()
        self.catalog = {e["name"]: e for e in out}
        return out

    def ensure_loaded(self, name):
        if name in self.mods:
            return True
        e = self.catalog.get(name)
        if e is None:
            self.refresh_catalog()
            e = self.catalog.get(name)
        if not e or not e.get("enabled", True):
            return False
        try:
            self.load(name, quiet=True)
        except Exception as ex:
            log.error("插件唤醒失败 %s: %s" % (name, ex))
            log.error(traceback.format_exc(limit=2))
            return False
        self.last_used[name] = time.time()
        log.info("插件已唤醒：%s" % name)
        try:
            fire(self.call_hook(name, "on_startup", self.bot))
        except Exception as ex:
            log.warn("插件 %s 启动钩子出错：%s" % (name, ex))
        return True

    @staticmethod
    def _cmd_match(entry, cmd):
        for c in (entry.get("cmds") or []):
            names = [c.get("name")] + list(c.get("aliases") or [])
            if cmd in [str(x) for x in names if x]:
                return True
        return False

    @staticmethod
    def _reclaimable(entry):
        hook_map = entry.get("hook_map") or {}
        runtime_hooks = [h for h in hook_map if h not in ("on_startup", "on_shutdown")]
        if not runtime_hooks:
            return True
        trg = entry.get("triggers") or {}
        if isinstance(trg, dict) and any(trg.get(h) for h in runtime_hooks):
            return True
        if isinstance(trg, list) and trg:
            return True
        return False

    def load(self, name, quiet=False):
        d = PLUGIN_DIR / name
        meta = read_json(d / "m.json", None)
        if not isinstance(meta, dict):
            raise RuntimeError("m.json 缺失或格式错误")
        if name in self.mods:
            self.unload(name, quiet=True)
        modname = "ywp_" + name
        spec = importlib.util.spec_from_file_location(modname, str(d / "main.py"))
        if spec is None or spec.loader is None:
            raise RuntimeError("main.py 无法加载")
        mod = importlib.util.module_from_spec(spec)
        sys.modules[modname] = mod
        sys.path.insert(0, str(d))
        try:
            spec.loader.exec_module(mod)
        finally:
            try:
                sys.path.remove(str(d))
            except ValueError:
                pass
        self.mods[name] = {"mod": mod, "meta": meta}
        self.last_used[name] = time.time()
        if not quiet:
            log.ok("插件已加载：%s v%s" % (meta.get("name") or name, meta.get("version") or "?"))
        return mod

    def unload(self, name, quiet=False):
        info = self.mods.pop(name, None)
        modname = "ywp_" + name
        sys.modules.pop(modname, None)
        for k in [k for k in list(sys.modules) if k.startswith(modname + ".")]:
            sys.modules.pop(k, None)
        if info and not quiet:
            log.info("插件已卸载并回收内存：%s" % name)
        gc.collect()

    def loaded_count(self):
        return len(self.mods)

    def get(self, name):
        info = self.mods.get(name)
        return info["mod"] if info else None

    def plugin_config(self, name):
        info = self.mods.get(name)
        meta = info["meta"] if info else read_json(PLUGIN_DIR / name / "m.json", {})
        schema = meta.get("config") or {}
        saved = self.conf.get(name, {})
        out = {}
        for k, v in schema.items():
            if isinstance(v, dict) and "default" in v:
                out[k] = saved.get(k, v.get("default"))
            else:
                out[k] = saved.get(k)
        return out

    def save_plugin_config(self, name, values):
        self.conf[name] = deep_merge(self.conf.get(name, {}), values)
        write_json(DATA / "plugin_config.json", self.conf)

    def set_enabled(self, name, enabled):
        self.meta.setdefault(name, {})["enabled"] = bool(enabled)
        write_json(DATA / "plugins.json", self.meta)
        self.refresh_catalog()
        if enabled:
            try:
                self.load(name)
                fire(self.call_hook(name, "on_startup", self.bot))
            except Exception as e:
                log.error("插件启用失败 %s: %s" % (name, e))
                return False
        else:
            try:
                fire(self.call_hook(name, "on_shutdown", self.bot))
            except Exception:
                pass
            self.unload(name)
        return True

    def is_admin(self, uid):
        admins = cfg.get("admins", default=[]) or []
        uid = str(uid or "").strip()
        return bool(uid) and any(str(a).strip() == uid for a in admins if str(a).strip())

    def admin_only(self, name):
        return bool(self.meta.get(name, {}).get("admin_only", False))

    def set_admin_only(self, name, value):
        self.meta.setdefault(name, {})["admin_only"] = bool(value)
        write_json(DATA / "plugins.json", self.meta)
        self.refresh_catalog()

    @staticmethod
    def _trigger_hit_any(entry, text):
        trg = entry.get("triggers") or {}
        words = []
        if isinstance(trg, dict):
            for v in trg.values():
                if isinstance(v, (list, tuple)):
                    words.extend(v)
                elif isinstance(v, str):
                    words.append(v)
        elif isinstance(trg, (list, tuple)):
            words = list(trg)
        text = str(text or "")
        return any(w and str(w) in text for w in words)

    def start_all(self):
        for p in self.refresh_catalog():
            if not p["enabled"]:
                continue
            try:
                self.load(p["name"], quiet=True)
                fire(self.call_hook(p["name"], "on_startup", self.bot))
            except Exception as e:
                log.error("插件启动失败 %s: %s" % (p["name"], e))
        n = self.loaded_count()
        if n:
            log.ok("已加载 %d 个插件" % n)

    def call_hook(self, name, hook, *args):
        info = self.mods.get(name)
        if not info:
            return None
        meta = info["meta"]
        fn_name = (meta.get("hooks") or {}).get(hook)
        if not fn_name:
            return None
        fn = getattr(info["mod"], fn_name, None)
        if not callable(fn):
            return None
        self.last_used[name] = time.time()
        res = fn(*args)
        if asyncio.iscoroutine(res):
            return res
        return res

    async def _run_hook(self, name, hook, ctx, *extra):
        if hook not in ("on_filter", "on_notice", "on_request", "on_tick", "on_startup", "on_shutdown"):
            if self.admin_only(name) and not self.is_admin(ctx.user_id):
                return False
        try:
            ctx.plugin = name
            ctx.cfg = self.plugin_config(name)
            res = self.call_hook(name, hook, ctx, *extra)
            if res is not None and asyncio.iscoroutine(res):
                res = await res
        except Exception as e:
            log.error("插件 %s 的 %s 出错：%s" % (name, hook, e))
            log.error(traceback.format_exc(limit=2))
            return False
        return bool(res)

    async def dispatch_hook(self, hook, ctx, *extra):
        for name in list(self.mods.keys()):
            if await self._run_hook(name, hook, ctx, *extra):
                return True
        if not self.catalog:
            self.refresh_catalog()
        for name, e in list(self.catalog.items()):
            if name in self.mods or not e.get("enabled", True):
                continue
            if hook not in (e.get("hook_map") or {}):
                continue
            if not self._trigger_hit(e, hook, ctx):
                continue
            if self.ensure_loaded(name) and await self._run_hook(name, hook, ctx, *extra):
                return True
        return False

    @staticmethod
    def _trigger_hit(entry, hook, ctx):
        trg = entry.get("triggers") or {}
        if isinstance(trg, dict):
            words = trg.get(hook) or []
        elif isinstance(trg, list):
            words = trg
        else:
            words = []
        if not words:
            return False
        text = getattr(ctx, "text", "") or ""
        return any(w and str(w) in text for w in words)

    async def _exec_command(self, name, ctx, cmd, args):
        info = self.mods.get(name)
        if not info:
            return False
        for c in (info["meta"].get("commands") or []):
            if not isinstance(c, dict):
                continue
            names = [c.get("name")]
            names += list(c.get("aliases") or [])
            if cmd not in [str(x) for x in names if x]:
                continue
            if self.admin_only(name) and not self.is_admin(ctx.user_id):
                await ctx.reply("权限不足")
                return True
            fn = getattr(info["mod"], c.get("handler") or "", None)
            if not callable(fn):
                continue
            self.last_used[name] = time.time()
            ctx.plugin = name
            ctx.cfg = self.plugin_config(name)
            try:
                res = fn(ctx, args)
                if asyncio.iscoroutine(res):
                    res = await res
                return True
            except Exception as e:
                log.error("指令 /%s 执行出错：%s" % (cmd, e))
                log.error(traceback.format_exc(limit=2))
                try:
                    await ctx.reply("执行出错啦：%s" % str(e)[:120])
                except Exception:
                    pass
                return True
        return False

    async def dispatch_command(self, ctx, cmd, args):
        for name in list(self.mods.keys()):
            if await self._exec_command(name, ctx, cmd, args):
                return True
        if not self.catalog:
            self.refresh_catalog()
        for name, e in list(self.catalog.items()):
            if name in self.mods or not e.get("enabled", True):
                continue
            if not self._cmd_match(e, cmd):
                continue
            if self.ensure_loaded(name) and await self._exec_command(name, ctx, cmd, args):
                return True
        return False

    def all_commands(self):
        if not self.catalog:
            self.refresh_catalog()
        out = []
        for name, e in self.catalog.items():
            if not e.get("enabled", True):
                continue
            for c in (e.get("cmds") or []):
                out.append({"plugin": name, "name": c.get("name"), "aliases": c.get("aliases") or [],
                            "usage": c.get("usage") or "", "description": c.get("description") or "",
                            "loaded": name in self.mods})
        return out

    def idle_reclaim(self):
        minutes = int(cfg.get("runtime", "plugin_idle_minutes", default=10) or 0)
        if minutes <= 0:
            return 0
        now = time.time()
        n = 0
        for name in list(self.mods.keys()):
            e = self.catalog.get(name)
            if e and not self._reclaimable(e):
                continue
            last = self.last_used.get(name, now)
            if now - last > minutes * 60:
                self.unload(name, quiet=True)
                n += 1
        if n:
            log.info("闲置插件已回收 %d 个，释放内存中" % n)
            gc.collect()
        return n


class Bot:
    def __init__(self):
        self.platforms = PlatformManager(self)
        self.plugins = PluginManager(self)
        self.ctxs = {}
        self.stats = {"recv": 0, "sent": 0, "llm": 0, "cmd": 0, "err": 0}
        self.started_at = time.time()
        self.last_activity = time.time()
        self._cool = {}

    def segments(self, event):
        msg = event.get("message")
        if isinstance(msg, list):
            return msg
        raw = event.get("raw_message") or ""
        segs = []
        for part in re.split(r"(\[CQ:[^\]]+\])", raw):
            if not part:
                continue
            m = re.match(r"\[CQ:([a-zA-Z_]+)(?:,([^\]]*))?\]", part)
            if not m:
                segs.append({"type": "text", "data": {"text": part}})
                continue
            data = {}
            if m.group(2):
                for kv in m.group(2).split(","):
                    if "=" in kv:
                        k, v = kv.split("=", 1)
                        data[k] = v
            segs.append({"type": m.group(1), "data": data})
        return segs

    def extract_text(self, event):
        segs = self.segments(event)
        parts = []
        for s in segs:
            t = s.get("type")
            if t == "text":
                parts.append(s.get("data", {}).get("text", ""))
            elif t == "image":
                parts.append("[图片]")
            elif t == "face":
                parts.append("[表情]")
        return "".join(parts).strip()

    def extract_images(self, event):
        out = []
        for s in self.segments(event):
            if s.get("type") != "image":
                continue
            d = s.get("data") or {}
            url = d.get("url") or d.get("file") or ""
            out.append(url)
        return out

    @property
    def ob(self):
        return self.platforms.primary()

    def is_at_me(self, segs, self_id=""):
        for s in segs:
            if s.get("type") == "at" and str(s.get("data", {}).get("qq")) == str(self_id or self.ob.self_id):
                return True
        return False

    async def handle_event(self, event):
        try:
            pt = event.get("post_type")
            if pt == "message":
                self.stats["recv"] += 1
                self.last_activity = time.time()
                if await self.plugins.dispatch_hook("on_filter", Ctx(self, event)):
                    return
                await self.on_message(event)
            elif pt == "notice":
                ctx = Ctx(self, event)
                await self.plugins.dispatch_hook("on_notice", ctx)
            elif pt == "request":
                ctx = Ctx(self, event)
                await self.plugins.dispatch_hook("on_request", ctx)
            elif pt == "meta_event":
                if event.get("meta_event_type") == "lifecycle":
                    sid = str(event.get("self_id") or "")
                    if sid:
                        link = event.get("_yw_link")
                        if link is not None:
                            link.self_id = sid
                        else:
                            self.ob.self_id = sid
        except Exception as e:
            self.stats["err"] += 1
            log.error("事件处理异常：%s" % e)
            log.error(traceback.format_exc(limit=3))

    async def guard_plugins(self, ctx, text):
        pm = self.plugins
        if not pm.catalog:
            pm.refresh_catalog()
        locked = [n for n, e in pm.catalog.items()
                  if e.get("enabled", True) and pm.admin_only(n)]
        if not locked or pm.is_admin(ctx.user_id):
            return False
        cmd, _args = self.parse_command(text)
        for name in locked:
            e = pm.catalog.get(name, {})
            if cmd and pm._cmd_match(e, cmd):
                await ctx.reply("权限不足")
                return True
            if pm._trigger_hit_any(e, text):
                await ctx.reply("权限不足")
                return True
        return False

    async def on_message(self, event):
        uid = str(event.get("user_id") or "")
        gid = str(event.get("group_id") or "")
        event_link = event.get("_yw_link")
        event_self_id = str(getattr(event_link, "self_id", "") or self.ob.self_id or "")
        if uid and uid == event_self_id:
            return
        segs = self.segments(event)
        text = self.extract_text(event)
        if not text and not self.extract_images(event):
            return

        if re.match(r"^[＃#]\s*YueWu(?:Bot)?\s*$", text.strip(), re.I):
            ctx = Ctx(self, event)
            ctx.text = text.strip()
            await ctx.reply(status_text())
            return

        hash_chat = False
        if (not gid) or cfg.get("reply", "group_hash_chat", default=True):
            m = re.match(r"^[#＃]\s*(.+)$", text.strip(), re.S)
            if m and m.group(1).strip():
                hash_chat = True
                text = m.group(1).strip()

        at_me = False
        hit_prefix = None
        free_ok = False
        if gid:
            if not cfg.get("reply", "group_at", default=True):
                return
            at_me = self.is_at_me(segs, event_self_id)
            if not hash_chat:
                for p in (cfg.get("reply", "prefixes", default=[]) or []):
                    if p and text.startswith(p):
                        hit_prefix = p
                        break
                if hit_prefix:
                    text = text[len(hit_prefix):].strip()
            if not at_me and not hit_prefix and not hash_chat:
                free_ok = bool(cfg.get("reply", "group_command_any", default=True))
                if not free_ok:
                    return
        else:
            if not cfg.get("reply", "private", default=True):
                return

        clean = re.sub(r"\[图片\]|\[表情\]", "", text).strip()
        if not clean:
            return

        ctx = Ctx(self, event)
        ctx.text = clean
        if await self.guard_plugins(ctx, clean):
            return
        if clean.lower() in ("yuewu", "yuewubot") and (hash_chat or at_me or hit_prefix or not gid):
            await ctx.reply(status_text())
            return
        cmd, args = self.parse_command(clean)
        no_at = bool(gid) and not at_me and not hit_prefix
        if hash_chat or (no_at and not self.is_slash_command(clean)):
            cmd = None

        if cmd:
            self.stats["cmd"] += 1
            if await self.run_builtin(ctx, cmd, args):
                return
            if await self.plugins.dispatch_command(ctx, cmd, args):
                return
            if no_at:
                return
            await ctx.reply("没有这个指令哦，发 /help 看看能干啥")
            return

        if hash_chat:
            key = gid or uid
            cd = float(cfg.get("reply", "cooldown", default=1.2) or 0)
            now = time.time()
            if now - self._cool.get(key, 0) < cd:
                return
            self._cool[key] = now
            await self.chat_reply(ctx)
            return

        hooked = await self.plugins.dispatch_hook(
            "on_group_message" if gid else "on_private_message", ctx)
        if hooked:
            return
        if await self.plugins.dispatch_hook("on_message", ctx):
            return
        if no_at:
            return

        key = gid or uid
        cd = float(cfg.get("reply", "cooldown", default=1.2) or 0)
        now = time.time()
        if now - self._cool.get(key, 0) < cd:
            return
        self._cool[key] = now

        await self.chat_reply(ctx)

    @staticmethod
    def is_slash_command(text):
        return bool(re.match(r"^[/／][a-zA-Z0-9_\u4e00-\u9fa5]{1,20}(?:\s|$)", (text or "").strip()))

    def parse_command(self, text):
        m = re.match(r"^[/／#!！]([a-zA-Z0-9_\u4e00-\u9fa5]{1,20})\s*(.*)$", text.strip(), re.S)
        if not m:
            return None, ""
        return m.group(1).lower(), m.group(2).strip()

    async def run_builtin(self, ctx, cmd, args):
        if cmd in ("help", "帮助", "菜单"):
            lines = ["内置：", "/help 帮助  /ping 延迟  /reset 清空上下文  /me 我的信息"]
            cmds = self.plugins.all_commands()
            if cmds:
                lines.append("插件：")
                for c in cmds[:30]:
                    lines.append("/%s %s" % (c["name"], c["description"]))
            await ctx.reply("\n".join(lines))
            return True
        if cmd in ("ping", "ping!"):
            await ctx.reply("pong")
            return True
        if cmd in ("yuewubot", "yuewu"):
            await ctx.reply(status_text())
            return True
        if cmd in ("reset", "清空", "重置"):
            self.ctxs.pop(self.ctx_key(ctx.event), None)
            await ctx.reply("上下文清空啦")
            return True
        if cmd in ("me", "我的信息"):
            await ctx.reply("你的QQ：%s\n昵称：%s\n群：%s" % (ctx.user_id, ctx.sender or "-", ctx.group_id or "私聊"))
            return True
        return False

    def ctx_key(self, event):
        gid = str(event.get("group_id") or "")
        uid = str(event.get("user_id") or "")
        return ("g:" + gid + ":" + uid) if gid else ("p:" + uid)

    def history(self, key):
        if key not in self.ctxs:
            n = int(cfg.get("reply", "max_context", default=12) or 12)
            self.ctxs[key] = collections.deque(maxlen=max(2, n))
        return self.ctxs[key]

    async def chat_reply(self, ctx):
        key = self.ctx_key(ctx.event)
        hist = self.history(key)
        system = cfg.get("llm", "system_prompt", default=DEFAULT_PERSONA)
        msgs = [{"role": "system", "content": system}]
        for role, content in hist:
            msgs.append({"role": role, "content": content})
        msgs.append({"role": "user", "content": ctx.text})

        try:
            reply = await llm.chat(msgs)
            self.stats["llm"] += 1
        except Exception as e:
            self.stats["err"] += 1
            log.error("模型调用失败：%s" % e)
            try:
                await ctx.reply("刚没接上信号，麻烦再说一遍嘛～")
            except Exception:
                pass
            return

        if not reply:
            return
        hist.append(("user", ctx.text))
        hist.append(("assistant", reply))

        limit = int(cfg.get("reply", "max_reply_chars", default=900) or 900)
        for chunk in self.split_text(reply, limit):
            try:
                await ctx.reply(chunk)
                self.stats["sent"] += 1
                await asyncio.sleep(0.35)
            except Exception as e:
                self.stats["err"] += 1
                log.error("发送失败：%s" % e)
                break

    def split_text(self, text, limit):
        text = (text or "").strip()
        if len(text) <= limit:
            return [text] if text else []
        parts = []
        while text:
            if len(text) <= limit:
                parts.append(text)
                break
            cut = text.rfind("\n", 0, limit)
            if cut < limit * 0.5:
                cut = max(text.rfind("。", 0, limit), text.rfind("！", 0, limit), text.rfind("？", 0, limit))
            if cut < limit * 0.5:
                cut = limit
            parts.append(text[:cut + 1].strip())
            text = text[cut + 1:].strip()
        return [p for p in parts if p]

    async def maintain(self):
        while True:
            await asyncio.sleep(60)
            try:
                sessions.gc()
                self.plugins.idle_reclaim()
                self.gc_ctx()
                self.gc_images()
                if rss_mb() > float(cfg.get("runtime", "memory_soft_mb", default=120) or 120):
                    gc.collect()
            except Exception as e:
                log.warn("维护任务异常：%s" % e)

    def gc_ctx(self):
        if len(self.ctxs) > 200:
            for k in list(self.ctxs.keys())[:100]:
                self.ctxs.pop(k, None)

    def gc_images(self):
        days = int(cfg.get("runtime", "image_keep_days", default=7) or 7)
        if days <= 0:
            return
        cutoff = time.time() - days * 86400
        for f in IMAGES.glob("*"):
            try:
                if f.is_file() and f.stat().st_mtime < cutoff:
                    f.unlink()
            except Exception:
                pass


def status_text():
    up = max(0, int(time.time() - STARTED_AT))
    return "YueWuBot\n版本:%s\n运行时间:%d天%d时%d分%d秒\n运行状态:正常" % (
        VERSION, up // 86400, up % 86400 // 3600, up % 3600 // 60, up % 60)


bot = Bot()


MIME = {
    ".html": "text/html; charset=utf-8",
    ".js": "application/javascript; charset=utf-8",
    ".css": "text/css; charset=utf-8",
    ".json": "application/json; charset=utf-8",
    ".png": "image/png",
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".gif": "image/gif",
    ".svg": "image/svg+xml",
    ".ico": "image/x-icon",
    ".webp": "image/webp",
    ".woff2": "font/woff2",
    ".txt": "text/plain; charset=utf-8",
}


def jok(data=None, **kw):
    out = {"ok": True}
    if isinstance(data, dict):
        out.update(data)
    elif data is not None:
        out["data"] = data
    out.update(kw)
    return web.json_response(out)


def jerr(msg, status=400):
    return web.json_response({"ok": False, "error": str(msg)}, status=status)


@web.middleware
async def auth_mw(request, handler):
    p = request.path
    if not p.startswith("/api/") or p in ("/api/auth/login", "/api/auth/state"):
        return await handler(request)
    auth = request.headers.get("Authorization", "")
    if auth.startswith("Bearer "):
        auth = auth[7:]
    if not auth:
        auth = request.query.get("t", "")
    if not sessions.valid(auth):
        return jerr("登录已失效，请重新登录", 401)
    return await handler(request)


async def api_auth_state(request):
    return jok({"need_login": True, "version": VERSION, "bot": cfg.get("platform", "self_id", default="")})


async def api_login(request):
    try:
        body = await request.json()
    except Exception:
        return jerr("请求格式错误")
    token = str(body.get("token") or "").strip()
    if not token or not hmac.compare_digest(token, str(cfg.get("token"))):
        log.warn("控制台登录失败，来源 %s" % request.remote)
        return jerr("令牌不正确", 401)
    s = sessions.create()
    log.ok("控制台登录成功，来源 %s" % request.remote)
    return jok({"session": s})


async def api_logout(request):
    auth = request.headers.get("Authorization", "").replace("Bearer ", "")
    sessions.revoke(auth)
    return jok()


async def api_overview(request):
    up = int(time.time() - bot.started_at)
    primary = bot.ob
    platforms = bot.platforms.snapshots()
    return jok({
        "version": VERSION,
        "uptime": up,
        "uptime_text": "%d天%d时%d分%d秒" % (up // 86400, up % 86400 // 3600, up % 3600 // 60, up % 60),
        "uptime_short": "%d天%d时%d分" % (up // 86400, up % 86400 // 3600, up % 3600 // 60),
        "rss_mb": rss_mb(),
        "online": primary.online,
        "self_id": primary.self_id or cfg.get("platform", "self_id", default=""),
        "nickname": primary.nickname,
        "platform_mode": primary.direction,
        "platform_url": primary.url,
        "platform_name": primary.name,
        "platforms": platforms,
        "platform_online": sum(1 for x in platforms if x.get("online")),
        "platform_total": len(platforms),
        "model": cfg.get("llm", "model", default=""),
        "has_key": bool(cfg.get("llm", "api_key", default="")),
        "stats": bot.stats,
        "plugins": {"total": len(bot.plugins.catalog or bot.plugins.refresh_catalog()),
                    "loaded": bot.plugins.loaded_count()},
        "llm_ms": llm.last_ms,
        "last_activity": int(bot.last_activity),
    })


async def api_config_get(request):
    data = json.loads(json.dumps(cfg.data))
    data.pop("token", None)
    return jok({"config": data})


async def api_config_set(request):
    try:
        patch = await request.json()
    except Exception:
        return jerr("请求格式错误")
    patch.pop("token", None)
    cfg.update(patch)
    if "platform" in patch:
        await bot.platforms.reload()
    log.ok("配置已更新")
    return jok({"config": {k: v for k, v in cfg.data.items() if k != "token"}})


async def api_platforms(request):
    return jok({"connections": bot.platforms.read_entries(), "active": bot.platforms.snapshots()})


async def api_platforms_save(request):
    try:
        body = await request.json()
    except Exception:
        return jerr("请求格式错误")
    items = body.get("connections")
    if not isinstance(items, list):
        return jerr("connections 必须是数组")
    if len(items) > 20:
        return jerr("最多支持 20 条连接")
    old = {x["id"]: x for x in bot.platforms.read_entries()}
    out = []
    seen = set()
    for i, raw in enumerate(items):
        if not isinstance(raw, dict):
            continue
        cid = slugify(raw.get("id") or ("conn-%d" % (i + 1)), "conn-%d" % (i + 1))
        if cid in seen:
            return jerr("连接 ID 重复：%s" % cid)
        seen.add(cid)
        direction = str(raw.get("direction") or "server").lower()
        if direction not in ("client", "server"):
            return jerr("连接 %s 的接入方式无效" % cid)
        url = str(raw.get("url") or "").strip()
        token = str(raw.get("access_token") or "").strip()
        if direction == "client":
            if not url:
                return jerr("主动连接 %s 必须填写 WS 地址" % cid)
            if not (url.startswith("ws://") or url.startswith("wss://")):
                return jerr("连接 %s 的地址必须以 ws:// 或 wss:// 开头" % cid)
        out.append({
            "id": cid,
            "name": str(raw.get("name") or cid),
            "direction": direction,
            "url": url,
            "access_token": token,
            "enabled": bool(raw.get("enabled", True)),
            "self_id": str(raw.get("self_id") or old.get(cid, {}).get("self_id") or ""),
        })
    if not out:
        return jerr("至少保留一条连接")
    cfg.update({"platform": {"links": out}})
    legacy = next((x for x in out if x["direction"] == "client" and x["enabled"]), None)
    if legacy is None:
        legacy = next((x for x in out if x["enabled"]), out[0])
    cfg.update({"platform": {
        "mode": legacy["direction"],
        "url": legacy["url"] if legacy["direction"] == "client" else "",
        "access_token": legacy["access_token"],
    }})
    await bot.platforms.reload()
    log.ok("平台连接配置已更新")
    return jok({"connections": bot.platforms.read_entries(), "active": bot.platforms.snapshots()})


async def api_platforms_reconnect(request):
    await bot.platforms.reload()
    log.warn("平台连接已重启")
    return jok({"active": bot.platforms.snapshots()})


async def api_token_show(request):
    return jok({"token": cfg.get("token")})


async def api_token_reset(request):
    cfg.data["token"] = secrets.token_urlsafe(96)[:128]
    cfg.save()
    sessions.map.clear()
    log.warn("访问令牌已重置，所有会话失效")
    return jok({"token": cfg.data["token"]})


async def api_plugins(request):
    return jok({"plugins": bot.plugins.refresh_catalog(), "commands": bot.plugins.all_commands(),
                "admins": cfg.get("admins", default=[]) or []})


def _safe_extract(zf, dest):
    dest = dest.resolve()
    for info in zf.infolist():
        name = info.filename.replace("\\", "/")
        if name.startswith("/") or ".." in Path(name).parts:
            continue
        target = (dest / name).resolve()
        try:
            target.relative_to(dest)
        except Exception:
            continue
        if info.is_dir():
            target.mkdir(parents=True, exist_ok=True)
            continue
        target.parent.mkdir(parents=True, exist_ok=True)
        with zf.open(info) as src, open(str(target), "wb") as out:
            shutil.copyfileobj(src, out)


def _zip_install(blob, source_name="upload.zip"):
    import tempfile
    tmp = Path(tempfile.mkdtemp(prefix="ywpz_"))
    try:
        zpath = tmp / "pkg.zip"
        zpath.write_bytes(blob)
        try:
            zf = zipfile.ZipFile(str(zpath))
        except Exception:
            raise RuntimeError("不是有效的 zip 文件")
        total = sum(i.file_size for i in zf.infolist())
        if total > 10 * 1024 * 1024:
            raise RuntimeError("压缩包解压后超过 10MB")
        if len(zf.infolist()) > 300:
            raise RuntimeError("压缩包文件数过多")
        _safe_extract(zf, tmp / "x")
        base = None
        if (tmp / "x" / "m.json").is_file():
            base = tmp / "x"
        else:
            for d in (tmp / "x").iterdir():
                if d.is_dir() and (d / "m.json").is_file():
                    base = d
                    break
        if base is None:
            raise RuntimeError("压缩包里没有 m.json")
        if not (base / "main.py").is_file():
            raise RuntimeError("压缩包里没有 main.py")
        meta = read_json(base / "m.json", None)
        if not isinstance(meta, dict):
            raise RuntimeError("m.json 不是合法的 JSON 对象")
        for f in base.rglob("*"):
            if f.is_file() and (f.name.startswith(".") or "__pycache__" in str(f)):
                try:
                    f.unlink()
                except Exception:
                    pass
        name = slugify(meta.get("name") or Path(source_name).stem, "plugin")
        dest = PLUGIN_DIR / name
        if dest.exists():
            shutil.rmtree(str(dest))
        shutil.copytree(str(base), str(dest))
        meta.setdefault("name", name)
        write_json(dest / "m.json", meta)
        pmeta = read_json(DATA / "plugins.json", {})
        pmeta.setdefault(name, {})["enabled"] = True
        pmeta[name]["installed_at"] = ts()
        write_json(DATA / "plugins.json", pmeta)
        bot.plugins.meta = pmeta
        bot.plugins.refresh_catalog()
        bot.plugins.load(name)
        fire(bot.plugins.call_hook(name, "on_startup", bot))
        return name, meta
    finally:
        shutil.rmtree(str(tmp), ignore_errors=True)


async def api_plugin_upload(request):
    reader = await request.multipart()
    blob = None
    fname = "upload.zip"
    while True:
        part = await reader.next()
        if part is None:
            break
        if part.name == "file":
            fname = part.filename or fname
            blob = await part.read()
            break
    if not blob:
        return jerr("没有收到文件")
    try:
        name, meta = _zip_install(blob, fname)
    except Exception as e:
        return jerr(str(e))
    log.ok("插件已安装：%s" % name)
    return jok({"name": name, "title": meta.get("name")})


async def api_plugin_toggle(request):
    name = request.match_info["name"]
    body = await request.json()
    enabled = bool(body.get("enabled"))
    if not (PLUGIN_DIR / name).is_dir():
        return jerr("插件不存在", 404)
    bot.plugins.set_enabled(name, enabled)
    return jok({"enabled": enabled})


async def api_plugin_delete(request):
    name = request.match_info["name"]
    d = PLUGIN_DIR / name
    if not d.is_dir():
        return jerr("插件不存在", 404)
    bot.plugins.unload(name)
    shutil.rmtree(str(d), ignore_errors=True)
    meta = read_json(DATA / "plugins.json", {})
    meta.pop(name, None)
    write_json(DATA / "plugins.json", meta)
    bot.plugins.meta = meta
    bot.plugins.refresh_catalog()
    log.warn("插件已删除：%s" % name)
    return jok()


async def api_plugin_icon(request):
    name = request.match_info["name"]
    d = PLUGIN_DIR / name
    meta = read_json(d / "m.json", {})
    icon = d / (meta.get("icon") or "icon.png")
    if not icon.is_file():
        raise web.HTTPNotFound()
    return web.FileResponse(str(icon))


async def api_plugin_config(request):
    name = request.match_info["name"]
    if not (PLUGIN_DIR / name / "m.json").is_file():
        return jerr("插件不存在", 404)
    if request.method == "GET":
        meta = read_json(PLUGIN_DIR / name / "m.json", {})
        return jok({"schema": meta.get("config") or {}, "values": bot.plugins.plugin_config(name)})
    body = await request.json()
    bot.plugins.save_plugin_config(name, body.get("values") or {})
    mod = bot.plugins.get(name)
    if mod and hasattr(mod, "on_config_changed"):
        try:
            r = mod.on_config_changed(bot.plugins.plugin_config(name))
            if asyncio.iscoroutine(r):
                await r
        except Exception as e:
            log.warn("插件配置回调失败：%s" % e)
    return jok({"values": bot.plugins.plugin_config(name)})


async def api_admins(request):
    if request.method == "GET":
        return jok({"admins": cfg.get("admins", default=[]) or []})
    try:
        body = await request.json()
    except Exception:
        return jerr("请求格式错误")
    raw = body.get("admins")
    if not isinstance(raw, list):
        return jerr("admins 必须是数组")
    out = []
    for x in raw:
        s = str(x).strip()
        if s.isdigit() and 4 <= len(s) <= 16 and s not in out:
            out.append(s)
    if len(out) > 50:
        return jerr("最多 50 个管理员")
    cfg.data["admins"] = out
    cfg.save()
    log.ok("管理员列表已更新，共 %d 人" % len(out))
    return jok({"admins": out})


async def api_plugin_admin(request):
    name = request.match_info["name"]
    if not (PLUGIN_DIR / name).is_dir():
        return jerr("插件不存在", 404)
    try:
        body = await request.json()
    except Exception:
        return jerr("请求格式错误")
    value = bool(body.get("admin_only"))
    bot.plugins.set_admin_only(name, value)
    log.ok("插件 %s 管理员限制：%s" % (name, "开启" if value else "关闭"))
    return jok({"admin_only": value})


async def api_logs(request):
    try:
        since = int(request.query.get("since", "0"))
    except Exception:
        since = 0
    items = [x for x in log.buf if x["id"] > since]
    return jok({"items": items[-300:], "seq": log.seq})


async def api_logs_stream(request):
    resp = web.StreamResponse(headers={
        "Content-Type": "text/event-stream",
        "Cache-Control": "no-cache",
        "X-Accel-Buffering": "no",
    })
    await resp.prepare(request)
    q = asyncio.Queue()
    log.subs.add(q)
    try:
        for item in log.tail(80):
            await resp.write(("data: " + json.dumps(item, ensure_ascii=False) + "\n\n").encode())
        while True:
            try:
                item = await asyncio.wait_for(q.get(), 25)
                await resp.write(("data: " + json.dumps(item, ensure_ascii=False) + "\n\n").encode())
            except asyncio.TimeoutError:
                await resp.write(b": ping\n\n")
    except Exception:
        pass
    finally:
        log.subs.discard(q)
    return resp


async def api_test_chat(request):
    body = await request.json()
    messages = body.get("messages") or []
    system = cfg.get("llm", "system_prompt", default=DEFAULT_PERSONA)
    msgs = [{"role": "system", "content": system}] + [
        {"role": m.get("role", "user"), "content": str(m.get("content", ""))} for m in messages[-12:]
    ]
    try:
        reply = await llm.chat(msgs)
    except Exception as e:
        return jerr(str(e), 500)
    return jok({"reply": reply, "ms": llm.last_ms})


async def api_llm_probe(request):
    body = await request.json()
    base = (body.get("base_url") or "").strip().rstrip("/")
    key = (body.get("api_key") or "").strip()
    model = (body.get("model") or "").strip()
    if not base or not key or not model:
        return jerr("请先填写地址、Key 和模型")
    url = base if base.endswith("/chat/completions") else base + "/chat/completions"
    if llm.session is None:
        llm.session = ClientSession()
    headers = {"Authorization": "Bearer " + key, "Content-Type": "application/json"}
    payload = {"model": model, "messages": [{"role": "user", "content": "ping"}], "max_tokens": 8}
    last = "模型连接失败"
    for i in range(3):
        try:
            async with llm.session.post(url, headers=headers, json=payload, timeout=8) as r:
                txt = await r.text()
                if r.status >= 400:
                    last = "HTTP %s: %s" % (r.status, txt[:200])
                    if r.status < 500:
                        return jerr(last)
                    await asyncio.sleep(0.35 * (i + 1))
                    continue
            try:
                data = json.loads(txt)
                reply = (data["choices"][0]["message"]["content"] or "").strip() or "OK"
            except Exception:
                reply = txt[:200]
            return jok({"reply": reply[:200]})
        except Exception as e:
            last = str(e)[:200]
            await asyncio.sleep(0.35 * (i + 1))
    return jerr(last, 500)


async def api_restart(request):
    log.warn("收到重启指令，2 秒后退出由 systemd 拉起")
    asyncio.get_event_loop().call_later(2, lambda: os._exit(3))
    return jok()


async def api_send_test(request):
    body = await request.json()
    target = str(body.get("target") or "").strip()
    text = str(body.get("text") or "").strip()
    mtype = body.get("type") or ("group" if body.get("group_id") else "private")
    if not target or not text:
        return jerr("缺少目标或内容")
    try:
        await bot.ob.send_text(mtype, target, text)
        return jok()
    except Exception as e:
        return jerr(str(e), 500)


async def ws_handler(request):
    conn_id = request.match_info.get("conn", "")
    link = bot.platforms.find_server_link(request, conn_id)
    if link is None:
        return web.Response(status=401, text="unauthorized")
    ws = web.WebSocketResponse(heartbeat=30, max_msg_size=0)
    await ws.prepare(request)
    await link.attach_server_ws(ws)
    try:
        async for msg in ws:
            if msg.type == WSMsgType.TEXT:
                link._on_raw(msg.data, ws)
    finally:
        link.detach_server_ws(ws)
    return ws


async def index_handler(request):
    return web.Response(body=_index_html(), headers={"Content-Type": "text/html; charset=utf-8",
                                                     "Cache-Control": "no-store"})


def _ver():
    try:
        return str(int((WEB / "app.js").stat().st_mtime))
    except Exception:
        return "1"


def _index_html():
    return (WEB / "index.html").read_text("utf-8").replace("__V__", _ver())


async def static_handler(request):
    if request.path.startswith("/api/"):
        return jerr("接口不存在", 404)
    rel = request.match_info.get("path", "")
    if rel in ("docs", "docs/"):
        rel = "docs.html"
    fp = (WEB / rel).resolve()
    try:
        fp.relative_to(WEB.resolve())
    except Exception:
        raise web.HTTPForbidden()
    if fp.is_dir():
        fp = fp / "index.html"
    if not fp.is_file():
        if "." in Path(rel).name:
            raise web.HTTPNotFound()
        fp = WEB / "index.html"
    ctype = MIME.get(fp.suffix.lower(), "application/octet-stream")
    if fp.suffix.lower() in (".html", ".js", ".css"):
        body = fp.read_bytes()
        try:
            body = body.decode("utf-8").replace("__V__", _ver()).encode("utf-8")
        except Exception:
            pass
        return web.Response(body=body, headers={"Content-Type": ctype, "Cache-Control": "no-store"})
    return web.Response(body=fp.read_bytes(), headers={"Content-Type": ctype, "Cache-Control": "no-cache"})


async def fish_page(request):
    fp = WEB / "fish.html"
    if not fp.is_file():
        raise web.HTTPNotFound()
    return web.Response(body=fp.read_bytes(), headers={"Content-Type": "text/html; charset=utf-8",
                                                      "Cache-Control": "no-store"})


def _fish_module():
    try:
        if "fishing" not in bot.plugins.mods:
            bot.plugins.ensure_loaded("fishing")
        return bot.plugins.get("fishing")
    except Exception as e:
        log.warn("钓鱼插件加载失败：%s" % e)
        return None


async def api_fish(request):
    action = request.match_info.get("action", "")
    if not re.match(r"^[a-z_]+$", action):
        return jerr("接口不存在", 404)
    mod = _fish_module()
    if mod is None:
        return jerr("钓鱼插件未安装或未启用", 404)
    fn = getattr(mod, "admin_" + action, None)
    if not callable(fn):
        return jerr("接口不存在", 404)
    data = dict(request.query)
    if request.method == "POST":
        try:
            body = await request.json()
            if isinstance(body, dict):
                data.update(body)
        except Exception:
            pass
    try:
        res = fn(bot, data)
        return jok(res if isinstance(res, dict) else {"data": res})
    except Exception as e:
        log.error("钓鱼后台 %s 出错：%s" % (action, e))
        return jerr(str(e), 400)


def build_app():
    app = web.Application(middlewares=[auth_mw], client_max_size=32 * 1024 * 1024)
    r = app.router
    r.add_get("/ws", ws_handler)
    r.add_get("/ws/{conn}", ws_handler)
    r.add_get("/api/platforms", api_platforms)
    r.add_post("/api/platforms", api_platforms_save)
    r.add_post("/api/platforms/reconnect", api_platforms_reconnect)
    r.add_get("/api/auth/state", api_auth_state)
    r.add_post("/api/auth/login", api_login)
    r.add_post("/api/auth/logout", api_logout)
    r.add_get("/api/overview", api_overview)
    r.add_get("/api/config", api_config_get)
    r.add_post("/api/config", api_config_set)
    r.add_get("/api/token", api_token_show)
    r.add_post("/api/token/reset", api_token_reset)
    r.add_get("/api/plugins", api_plugins)
    r.add_post("/api/plugins/upload", api_plugin_upload)
    r.add_post("/api/plugins/{name}/toggle", api_plugin_toggle)
    r.add_post("/api/plugins/{name}/admin", api_plugin_admin)
    r.add_get("/api/admins", api_admins)
    r.add_post("/api/admins", api_admins)
    r.add_delete("/api/plugins/{name}", api_plugin_delete)
    r.add_get("/api/plugins/{name}/icon", api_plugin_icon)
    r.add_get("/api/plugins/{name}/config", api_plugin_config)
    r.add_post("/api/plugins/{name}/config", api_plugin_config)
    r.add_get("/api/logs", api_logs)
    r.add_get("/api/logs/stream", api_logs_stream)
    r.add_post("/api/chat", api_test_chat)
    r.add_post("/api/llm/probe", api_llm_probe)
    r.add_post("/api/send", api_send_test)
    r.add_post("/api/restart", api_restart)
    r.add_get("/fish", fish_page)
    r.add_get("/fish/", fish_page)
    r.add_get("/api/fish/{action}", api_fish)
    r.add_post("/api/fish/{action}", api_fish)
    r.add_get("/", index_handler)
    r.add_get("/{path:.*}", static_handler)
    r.add_post("/{path:.*}", static_handler)
    return app


async def amain():
    loop = asyncio.get_event_loop()
    app = build_app()
    runner = web.AppRunner(app, access_log=None)
    await runner.setup()
    for h in [x.strip() for x in HOST.split(",") if x.strip()]:
        await web.TCPSite(runner, h, PORT).start()
    log.ok("YueWuBot v%s 已启动，控制台监听 %s:%d" % (VERSION, HOST, PORT))
    log.info("访问令牌：%s" % cfg.get("token"))

    bot.plugins.start_all()
    bot.platforms.start_all()
    loop.create_task(bot.maintain())

    stop = loop.create_future()

    def _bye():
        if not stop.done():
            stop.set_result(1)

    for sig in (2, 15):
        try:
            loop.add_signal_handler(sig, _bye)
        except NotImplementedError:
            pass
    await stop
    log.warn("正在退出……")
    try:
        for name in list(bot.plugins.mods.keys()):
            bot.plugins.call_hook(name, "on_shutdown", bot)
    except Exception:
        pass
    for link in bot.platforms.links:
        try:
            await link.stop()
        except Exception:
            pass
    await runner.cleanup()


if __name__ == "__main__":
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    try:
        loop.run_until_complete(amain())
    except KeyboardInterrupt:
        pass
