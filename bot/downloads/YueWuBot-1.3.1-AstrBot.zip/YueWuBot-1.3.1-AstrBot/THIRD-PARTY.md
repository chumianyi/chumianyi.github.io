# 第三方组件声明

纯净版（`YueWuBot-1.3.1-src-noRepo.zip`）不包含第三方源码。完整兼容版另外收录 AstrBot 官方插件加载机制源码，见下表与 `astrbot_official/LICENSE`。

| 组件 | 用途 | 许可证 | 项目地址 |
| --- | --- | --- | --- |
| aiohttp | 异步 HTTP 服务与 WebSocket 客户端 | Apache-2.0 | https://github.com/aio-libs/aiohttp |
| Python | 解释器（系统或用户自行安装，不随包分发） | PSF License | https://www.python.org |
| AstrBot（仅完整兼容版） | 插件加载机制源码参考，原文随包放在 `astrbot_official/`，版权归原作者 | AGPL-3.0 | https://github.com/AstrBotDevs/AstrBot |

aiohttp 以 Apache License 2.0 授权，许可证原文随其发行包提供（`.venv/lib/python*/site-packages/aiohttp-*.dist-info/LICENSE.txt`）。

内置插件（weather / signin / wallpaper / love_like）与本软件同许可，均为 MIT。

AstrBot 以 GNU Affero General Public License v3.0 授权，许可证原文随完整兼容版提供（`astrbot_official/LICENSE`）。本包中 `astrbot_compat.py` 依据该源码的加载机制实现，属于演绎作品，同样遵循 AGPL-3.0；纯净版不含相关代码，保持 MIT 许可。
