# YueWuBot

极简 QQ 机器人。单进程、低内存（常驻约 26 MB）、插件化、自带 Web 控制台。
兼容 Python 3.6+ 与 OneBot v11（SnowLuma / NapCat / LLOneBot 等）。

## 环境要求

- Linux x86_64（CentOS 7 / Debian / Ubuntu 均可）
- Python 3.6 及以上
- 能访问 PyPI（脚本默认用清华源，可用 `PIP_MIRROR` 覆盖）

## 快速开始

```bash
chmod +x start.sh
./start.sh
```

脚本会自动完成：创建 `.venv` -> 安装 `aiohttp` -> 生成默认配置 -> 启动服务。
有 systemd 时注册为 `yuewubot.service` 并开机自启，否则后台运行并在 `logs/app.log` 留日志。

启动完成后会打印控制台地址和 128 位登录令牌：

```
控制台  http://127.0.0.1:6199
令牌    xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
```

令牌只在本机生成，不随包分发，重启不会变化；忘记可执行 `./start.sh token`。

## 常用命令

| 命令 | 说明 |
| --- | --- |
| `./start.sh` | 安装并启动 |
| `./start.sh fg` | 前台运行，调试用 |
| `./start.sh stop` | 停止 |
| `./start.sh restart` | 重启 |
| `./start.sh status` | 运行状态 |
| `./start.sh logs` | 实时日志 |
| `./start.sh token` | 查看登录令牌 |
| `./start.sh uninstall` | 卸载服务（保留数据） |

端口和监听地址用环境变量控制：

```bash
YW_PORT=7000 YW_HOST=0.0.0.0 ./start.sh
```

## 首次配置

打开控制台 -> 用令牌登录 -> 两处必填：

1. **模型**：填 OpenAI 兼容接口地址、API Key、模型名（默认 DeepSeek）
2. **平台**：填 OneBot 的 WS 地址与令牌，保存后自动重连

平台侧（以 SnowLuma 为例）把反向 WS 或正向 WS 指向 `ws://服务器IP:6199/ws`，
或让 YueWuBot 主动连平台的 `ws://127.0.0.1:3001`。

## 目录

```
yuewubot.py     主程序（单文件）
web/            控制台前端（index.html / style.css / app.js / docs.html）
plugins/        已安装插件（每个插件一个目录）
data/           运行时生成：config.json / 插件配置 / 图片缓存
logs/           非 systemd 模式下的运行日志
start.sh        安装与管理脚本
```

本版本不含官方仓库（无 `repo/` 目录、无仓库页面与仓库接口），插件请在控制台「插件」页上传 zip 安装。

`data/` 与 `.venv/` 不随包分发，删除后重启会重新生成（令牌会变）。

## 插件

zip 包，根目录放 `main.py` + `m.json`，可选 `icon.png`，其余资源放 `assets/`。

```json
{
  "name": "示例插件",
  "version": "1.0.0",
  "author": "you",
  "description": "一句话介绍",
  "hooks": { "on_message": "on_message" },
  "triggers": { "on_message": ["关键词"] },
  "commands": [
    { "name": "签到", "aliases": ["qd"], "description": "每日签到", "usage": "/签到", "handler": "cmd_signin" }
  ],
  "config": { "bonus": { "type": "number", "label": "奖励", "default": 10 } }
}
```

```python
async def on_message(ctx):
    if "关键词" not in ctx.text:
        return False
    await ctx.reply("收到")
    return True
```

`ctx` 提供 `text` / `user_id` / `group_id` / `images` / `cfg`，
以及 `await ctx.reply()`、`await ctx.send_image()`、`await ctx.llm()`、`await ctx.api("send_like", ...)`。

完整说明见控制台内「开发文档」页（`/docs`）。

## 状态指令

向机器人发送 `#YueWu`（群聊免 @，私聊亦可）会立即返回：

```
YueWuBot
版本:1.3.1
运行时间:0天1时2分3秒
运行状态:正常
```

该指令不走模型、不受回复规则开关影响。

## 多 WebSocket 接入

控制台「平台」页可同时管理多条 OneBot 连接（最多 20 条），每条有独立名称、ID、方向、令牌与在线状态：

- **等待平台连入（server）**：平台填 `ws://HOST:PORT/ws?conn=连接ID&access_token=令牌`
- **主动连接平台（client）**：机器人按填写的 WS 地址主动连过去

每条消息会记录来源连接，回复自动发回同一条连接，多个账号同时在线不会串号。旧版单一 `platform.mode` / `url` / `access_token` 配置会自动兼容为一条默认连接。

## 模型容错

上游偶发 5xx 或超时时自动重试（默认 3 次、单次超时 8 秒），可在「模型」页调整。接口为 DeepSeek 官方时，已下线的 `deepseek-chat` 等旧模型名会在启动时自动迁移为 `deepseek-flash`。

## 说明

- 控制台默认只监听 `127.0.0.1`，对外访问建议用 Nginx 反代并加 HTTPS
- 插件与主程序同权限运行，只安装可信来源的包
- 内置 memory 保护：systemd 单元限制 300 MB，超限自动重启


## 内置插件

| 插件 | 说明 |
| --- | --- |
| 群欢迎 | 有人进群自动 @ 新人并问好，主人 QQ 可在控制台配置 |
| 入群与好友审批 | 好友申请与入群邀请先私聊主人，`/同意 QQ号或群号` 才放行，`/拒绝` 默认拒绝全部待审批 |
| 黑名单 | 名单内 QQ 完全无法与机器人交互，`/拉黑` `/解封` `/黑名单` 管理，主人不受限制 |
| 功能菜单 | 发送「菜单」查看全部功能，群聊免 @ 触发 |
| 爱点赞 / 签到 / 天气 / 壁纸 | 原有内置插件 |

## 版本说明

本包为纯净版，不含 AstrBot 兼容组件。需要运行 AstrBot 格式插件请使用 `YueWuBot-1.3.1-AstrBot.zip`。
