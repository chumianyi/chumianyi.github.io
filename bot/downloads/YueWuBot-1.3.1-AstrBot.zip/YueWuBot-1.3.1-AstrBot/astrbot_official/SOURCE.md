# AstrBot 官方源码

本目录收录 [AstrBotDevs/AstrBot](https://github.com/AstrBotDevs/AstrBot) 官方仓库 `master` 分支中与插件加载机制相关的源码原文，用于说明本版本兼容层所依据的加载流程。

原项目以 **AGPL-3.0（GNU Affero General Public License v3.0）** 授权，许可证原文见同目录 `LICENSE`。收录文件版权归原作者所有，未做修改。

| 文件 | 对应加载机制 |
| --- | --- |
| `core/star/star.py` | `StarMetadata`、`star_map`、`star_registry` 元数据注册表 |
| `core/star/base.py` | `Star` 基类与 `__init_subclass__` 自动注册 |
| `core/star/star_handler.py` | `EventType`、`StarHandlerMetadata`、`StarHandlerRegistry`、`star_handlers_registry` |
| `core/star/register/star.py` | `register_star` 装饰器 |
| `core/star/register/star_handler.py` | `get_handler_or_create`、`register_command`、`register_regex` 等注册装饰器 |
| `core/star/filter/command.py` | `CommandFilter` 指令匹配与参数转换 |
| `core/star/filter/*.py` | 正则、权限、消息类型、指令组等过滤器 |
| `core/star/star_manager.py` | 官方 `PluginManager` 的插件发现、导入、实例化与回收流程 |
| `core/message/message_event_result.py` | `MessageEventResult` / `MessageChain` 结果对象 |
| `core/platform/astr_message_event.py` | `AstrMessageEvent` 事件对象 |
| `api/*` | 官方插件开发 API 导出 |

运行时加载器 `astrbot_compat.py` 按上述源码的类名、注册表结构与分发流程实现，去掉了对数据库、LLM Provider、调度器等重量级运行时的依赖，从而可以在纯 aiohttp 环境中按需加载并空闲回收。
