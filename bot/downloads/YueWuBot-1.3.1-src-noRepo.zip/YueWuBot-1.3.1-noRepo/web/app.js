(() => {
  'use strict';

  const BASE = (location.pathname.replace(/\/[^/]*$/, '/') || '/').replace(/\/?$/, '/');
  const ORIGIN = location.origin;
  const API = (p) => BASE + 'api/' + p.replace(/^\//, '');
  let SESSION = localStorage.getItem('yw_session') || '';
  let TIMER = null;
  let EVT = null;

  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  }[c]));
  const val = (id) => $(id).value.trim();

  function toast(msg, type) {
    const el = $('#toast');
    el.textContent = msg;
    el.className = 'toast show ' + (type || '');
    clearTimeout(el._t);
    el._t = setTimeout(() => { el.className = 'toast ' + (type || ''); }, 2800);
  }

  async function api(path, opts = {}) {
    const o = Object.assign({ method: 'GET', headers: {} }, opts);
    o.headers = Object.assign({ Authorization: 'Bearer ' + SESSION }, o.headers);
    if (o.body && !(o.body instanceof FormData)) {
      o.headers['Content-Type'] = 'application/json';
      o.body = JSON.stringify(o.body);
    }
    const r = await fetch(API(path), o);
    if (r.status === 401) { logout(true); throw new Error('登录已失效'); }
    let data = {};
    try { data = await r.json(); } catch (e) {}
    if (!r.ok || data.ok === false) throw new Error(data.error || ('HTTP ' + r.status));
    return data;
  }

  function modal(html) {
    const m = $('#modal');
    m.innerHTML = '<div class="modal-card">' + html + '</div>';
    m.classList.remove('hidden');
    m.onclick = (e) => { if (e.target === m) closeModal(); };
    return $('.modal-card', m);
  }

  function closeModal() {
    $('#modal').classList.add('hidden');
    $('#modal').innerHTML = '';
  }

  function paintTop(o) {
    if (!o) return;
    $('#dot').className = 'pulse-dot' + (o.online ? ' on' : '');
    $('#sideState').textContent = o.online ? (o.nickname || '已连接') : '未连接';
    $('#sideSub').textContent = o.online ? ('QQ ' + (o.self_id || '-')) : '等待平台接入';
    $('#rssPill').textContent = o.rss_mb + ' MB';
    const total = o.platform_total || 0;
    const online = o.platform_online || 0;
    const chip = $('#qqPill');
    chip.textContent = total > 1 ? ('平台 ' + online + '/' + total) : (o.self_id ? 'QQ ' + o.self_id : '未连接');
    chip.className = 'status-chip ' + (online ? 'online' : 'offline');
  }

  function startPolling() {
    clearInterval(TIMER);
    TIMER = setInterval(async () => {
      try { paintTop(await api('overview')); } catch (e) {}
    }, 8000);
  }

  function showLogin() {
    $('#login').classList.remove('hidden');
    $('#app').classList.add('hidden');
    closeDrawer();
  }

  function showApp() {
    $('#login').classList.add('hidden');
    $('#app').classList.remove('hidden');
    go((location.hash || '#dashboard').slice(1));
  }

  function logout(silent) {
    SESSION = '';
    localStorage.removeItem('yw_session');
    if (EVT) { EVT.close(); EVT = null; }
    clearInterval(TIMER);
    closeDrawer();
    showLogin();
    if (!silent) toast('已退出登录');
  }

  async function doLogin() {
    const tk = val('#tokenInput');
    if (!tk) { $('#loginHint').textContent = '请输入访问令牌'; return; }
    const btn = $('#loginBtn');
    btn.disabled = true;
    btn.querySelector('span').textContent = '验证中…';
    try {
      const r = await fetch(API('auth/login'), {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ token: tk })
      });
      const d = await r.json();
      if (!r.ok || !d.ok) throw new Error(d.error || '令牌不正确');
      SESSION = d.session;
      localStorage.setItem('yw_session', SESSION);
      $('#loginHint').textContent = '';
      showApp();
      paintTop(await api('overview'));
      startPolling();
      toast('登录成功', 'ok');
    } catch (e) {
      $('#loginHint').textContent = e.message;
    } finally {
      btn.disabled = false;
      btn.querySelector('span').textContent = '进入控制台';
    }
  }

  const PAGES = {
    dashboard: ['概览', '运行状态、平台链路与实时指标', renderDashboard],
    chat: ['试聊', '直接和模型对话，不经过 QQ', renderChat],
    model: ['模型', '配置 OpenAI 兼容接口与系统人设', renderModel],
    platform: ['平台', '多 WS 接入、回复规则与控制台令牌', renderPlatforms],
    plugins: ['插件', '上传、启用、配置与休眠管理', renderPlugins],
    logs: ['日志', '实时运行日志', renderLogs]
  };

  function go(page) {
    if (!PAGES[page]) page = 'dashboard';
    if (page !== 'logs' && EVT) { EVT.close(); EVT = null; }
    $$('#nav a[data-page], #tabbar a').forEach(a => a.classList.toggle('active', a.dataset.page === page));
    $('#pageTitle').textContent = PAGES[page][0];
    $('#pageSub').textContent = PAGES[page][1];
    const view = $('#view');
    view.innerHTML = '<div class="card"><div class="muted">加载中…</div></div>';
    PAGES[page][2](view);
    closeDrawer();
  }

  async function renderDashboard(view) {
    let d;
    try { d = await api('overview'); } catch (e) { return; }
    paintTop(d);
    const s = d.stats || {};
    const platforms = d.platforms || [];
    const primary = platforms.find(x => x.online && x.self_id) || platforms.find(x => x.online) || platforms[0] || {};
    view.innerHTML = `
      <section class="hero">
        <span class="hero-eyebrow"><span class="status-dot"></span>${d.online ? '系统运行正常' : '等待平台连接'}</span>
        <h2>YueWuBot 控制台</h2>
        <p>统一管理多路 OneBot WebSocket、模型、插件与运行状态。向机器人发送 <span class="mono">#YueWu</span> 可获取版本、运行时长和状态。</p>
        <div class="hero-meta">
          <span>v${esc(d.version)}</span>
          <span>平台 ${d.platform_online || 0}/${d.platform_total || 0}</span>
          <span>内存 ${d.rss_mb} MB</span>
          <span>插件 ${d.plugins.loaded}/${d.plugins.total}</span>
        </div>
      </section>
      <div class="grid g4" style="margin-bottom:16px">
        <div class="card metric"><span class="metric-label">运行时长</span><span class="metric-value">${esc(d.uptime_short)}</span><div class="metric-note">启动后连续运行</div></div>
        <div class="card metric"><span class="metric-label">内存占用</span><span class="metric-value">${d.rss_mb}<small>MB</small></span><div class="metric-note">单进程常驻</div></div>
        <div class="card metric"><span class="metric-label">消息统计</span><span class="metric-value">${s.recv || 0}</span><div class="metric-note">发送 ${s.sent || 0} · 指令 ${s.cmd || 0}</div></div>
        <div class="card metric"><span class="metric-label">模型响应</span><span class="metric-value">${d.llm_ms || 0}<small>ms</small></span><div class="metric-note">${esc(d.model || '未配置')}</div></div>
      </div>
      <div class="grid g2" style="margin-bottom:16px">
        <div class="card">
          <div class="card-title"><h3>当前主连接</h3><span class="tag">OneBot v11</span></div>
          <div class="info-list">
            <div class="info-row"><span>连接名称</span><b>${esc(primary.name || '--')}</b></div>
            <div class="info-row"><span>链路状态</span><span class="badge ${primary.online ? 'on' : 'off'}"><span class="status-dot"></span>${primary.online ? '已连接' : '未连接'}</span></div>
            <div class="info-row"><span>登录账号</span><span class="mono">${esc(primary.self_id || '--')}${primary.nickname ? ' · ' + esc(primary.nickname) : ''}</span></div>
            <div class="info-row"><span>接入方式</span><span>${primary.direction === 'client' ? '主动连接' : '等待平台连入'}</span></div>
            <div class="info-row"><span>模型 Key</span><span class="badge ${d.has_key ? 'on' : 'off'}">${d.has_key ? '已配置' : '未配置'}</span></div>
          </div>
        </div>
        <div class="card">
          <div class="card-title"><h3>快捷入口</h3><span class="tag">Quick Actions</span></div>
          <div class="stack">
            <a class="step" href="#platform"><span class="step-num">1</span><span><b>管理多 WS</b><p>添加 SnowLuma、NapCat 或其他 OneBot 平台连接。</p></span></a>
            <a class="step" href="#model"><span class="step-num">2</span><span><b>配置模型</b><p>填写 OpenAI 兼容接口、Key 与模型名。</p></span></a>
            <a class="step" href="#plugins"><span class="step-num">3</span><span><b>安装插件</b><p>上传 zip 即可安装。</p></span></a>
          </div>
        </div>
      </div>
      <div class="card" style="margin-bottom:16px">
        <div class="card-title"><h3>平台连接</h3><span class="tag">${platforms.filter(x => x.online).length}/${platforms.length} 在线</span></div>
        <div class="grid ${platforms.length > 2 ? 'g3' : 'g2'}">
          ${platforms.map(x => `
            <div class="card hover platform-card">
              <div class="platform-top">
                <div class="platform-icon">${esc((x.name || x.id || 'P')[0].toUpperCase())}</div>
                <div class="platform-name"><b>${esc(x.name)}</b><small>${esc(x.id)} · ${x.direction === 'client' ? '主动连接' : '等待连入'}</small></div>
                <span class="badge ${x.online ? 'on' : 'off'}" style="margin-left:auto"><span class="status-dot"></span>${x.online ? '在线' : '离线'}</span>
              </div>
              <div class="platform-url mono">${esc(x.direction === 'client' ? (x.url || '未填写地址') : ('/ws?conn=' + x.id))}</div>
              <div class="platform-actions">
                <span class="badge ${x.self_id ? 'on' : ''}">${x.self_id ? 'QQ ' + esc(x.self_id) : '未登录'}</span>
                ${x.active > 1 ? `<span class="badge">${x.active} 条 WS</span>` : ''}
                ${x.last_error ? `<span class="badge err" title="${esc(x.last_error)}">有错误</span>` : ''}
              </div>
            </div>`).join('')}
        </div>
      </div>
      <div class="grid g3">
        <div class="card"><div class="card-title"><h3>第 1 步</h3><span class="tag">Platform</span></div><p class="muted">在平台页添加多条 WS，保存后自动应用并支持独立令牌。</p></div>
        <div class="card"><div class="card-title"><h3>第 2 步</h3><span class="tag">Model</span></div><p class="muted">配置 DeepSeek 或其他 OpenAI 兼容模型，点击测试连接。</p></div>
        <div class="card"><div class="card-title"><h3>第 3 步</h3><span class="tag">Plugins</span></div><p class="muted">插件闲置自动回收内存，触发指令或关键词时自动唤醒。</p></div>
      </div>`;
  }

  let CHAT = [];
  function renderChat(view) {
    view.innerHTML = `
      <div class="card chat-shell">
        <div class="chat-head"><b>试聊</b><span class="tiny">仅在本页与模型对话</span><span class="spacer"></span><button class="btn ghost sm" id="clearChat">清空</button></div>
        <div class="chat-list" id="chatList"></div>
        <div class="chat-tip">回复由模型页的系统人设控制，不会发送到 QQ。</div>
        <div class="chat-form"><input class="input" id="chatText" placeholder="说点什么…（Enter 发送）"><button class="btn primary" id="chatSend">发送</button></div>
      </div>`;
    const list = $('#chatList');
    const paint = () => {
      list.innerHTML = CHAT.length ? CHAT.map(m => `<div class="message ${m.role === 'user' ? 'user' : 'bot'}">${esc(m.content)}</div>`).join('') : '<div class="chat-empty">还没有对话，先发一条试试</div>';
      list.scrollTop = list.scrollHeight;
    };
    paint();
    const send = async () => {
      const t = val('#chatText');
      if (!t) return;
      $('#chatText').value = '';
      CHAT.push({ role: 'user', content: t });
      paint();
      const btn = $('#chatSend');
      btn.disabled = true;
      btn.textContent = '…';
      try {
        const d = await api('chat', { method: 'POST', body: { messages: CHAT } });
        CHAT.push({ role: 'assistant', content: d.reply });
      } catch (e) {
        CHAT.push({ role: 'assistant', content: '［出错］' + e.message });
      } finally {
        btn.disabled = false;
        btn.textContent = '发送';
        paint();
      }
    };
    $('#chatSend').onclick = send;
    $('#chatText').onkeydown = (e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(); } };
    $('#clearChat').onclick = () => { CHAT = []; paint(); };
  }

  async function renderModel(view) {
    let c;
    try { c = (await api('config')).config; } catch (e) { return; }
    const l = c.llm || {};
    view.innerHTML = `
      <div class="grid g2">
        <div class="card">
          <div class="card-title"><h3>模型接口</h3><span class="tag">OpenAI 兼容</span></div>
          <div class="field"><label class="field-label" for="mBase">接口地址</label><input class="input" id="mBase" value="${esc(l.base_url || '')}" placeholder="https://api.deepseek.com/v1"></div>
          <div class="field"><label class="field-label" for="mKey">API Key</label><input class="input" id="mKey" type="password" value="${esc(l.api_key || '')}" placeholder="sk-..."></div>
          <div class="field-grid">
            <div class="field"><label class="field-label" for="mModel">模型名</label><input class="input" id="mModel" value="${esc(l.model || '')}" placeholder="deepseek-flash"></div>
            <div class="field"><label class="field-label" for="mTemp">温度</label><input class="input" id="mTemp" type="number" step="0.05" min="0" max="2" value="${esc(l.temperature)}"></div>
          </div>
          <div class="field-grid">
            <div class="field"><label class="field-label" for="mMax">最大回复 Token</label><input class="input" id="mMax" type="number" min="64" max="8192" value="${esc(l.max_tokens)}"></div>
            <div class="field"><label class="field-label" for="mVision">多模态</label><select class="select" id="mVision"><option value="0" ${l.vision ? '' : 'selected'}>关闭（纯文本）</option><option value="1" ${l.vision ? 'selected' : ''}>开启（支持读图）</option></select></div>
          </div>
          <div class="field-grid">
            <div class="field"><label class="field-label" for="mRetry">失败重试次数</label><input class="input" id="mRetry" type="number" min="1" max="5" value="${esc(l.retries || 3)}"></div>
            <div class="field"><label class="field-label" for="mTimeout">单次超时（秒）</label><input class="input" id="mTimeout" type="number" min="3" max="60" value="${esc(l.timeout || 8)}"></div>
          </div>
          <p class="tiny" style="margin:12px 0 16px">上游偶发 5xx 时自动重试；短超时可快速跳过无响应节点。</p>
          <div class="actions"><button class="btn primary" id="saveModel">保存</button><button class="btn" id="probeModel">测试连接</button></div>
        </div>
        <div class="card">
          <div class="card-title"><h3>系统人设</h3><span class="tag">System Prompt</span></div>
          <textarea class="textarea" id="mSys" style="min-height:328px">${esc(l.system_prompt || '')}</textarea>
          <div class="actions" style="margin-top:14px"><button class="btn primary" id="saveSys">保存人设</button></div>
          <p class="tiny" style="margin-top:12px">这段提示词会作为所有对话的系统消息，可定义语气、规则、口癖与回复边界。</p>
        </div>
      </div>`;
    const collect = () => ({
      llm: {
        base_url: val('#mBase'), api_key: val('#mKey'), model: val('#mModel'),
        temperature: parseFloat(val('#mTemp')) || 0.8, max_tokens: parseInt(val('#mMax')) || 800,
        retries: parseInt(val('#mRetry')) || 3, timeout: parseFloat(val('#mTimeout')) || 8,
        vision: $('#mVision').value === '1'
      }
    });
    $('#saveModel').onclick = async () => {
      try { await api('config', { method: 'POST', body: collect() }); toast('模型配置已保存', 'ok'); }
      catch (e) { toast(e.message, 'err'); }
    };
    $('#saveSys').onclick = async () => {
      try { await api('config', { method: 'POST', body: { llm: { system_prompt: $('#mSys').value } } }); toast('人设已保存', 'ok'); }
      catch (e) { toast(e.message, 'err'); }
    };
    $('#probeModel').onclick = async (ev) => {
      const b = ev.currentTarget;
      b.disabled = true;
      b.textContent = '测试中…';
      try {
        const d = await api('llm/probe', { method: 'POST', body: { base_url: val('#mBase'), api_key: val('#mKey'), model: val('#mModel') } });
        toast('连接成功：' + (d.reply || 'OK'), 'ok');
      } catch (e) { toast(e.message, 'err'); }
      finally { b.disabled = false; b.textContent = '测试连接'; }
    };
  }

  function wsEndpoint(id, token) {
    const scheme = location.protocol === 'https:' ? 'wss://' : 'ws://';
    let url = scheme + location.host + BASE + 'ws?conn=' + encodeURIComponent(id || 'default');
    if (token) url += '&access_token=' + encodeURIComponent(token);
    return url;
  }

  function connTemplate(c, active, index) {
    const a = active.find(x => x.id === c.id) || {};
    const client = c.direction === 'client';
    const endpoint = client ? (c.url || '') : wsEndpoint(c.id, c.access_token);
    return `
      <div class="conn" data-index="${index}">
        <div class="conn-head">
          <span class="badge ${a.online ? 'on' : 'off'}"><span class="status-dot"></span>${a.online ? '在线' : '离线'}</span>
          <b>${esc(c.name || '新连接')}</b>
          <span class="tiny mono">${esc(c.id || '')}</span>
          <span class="spacer"></span>
          <label class="check"><input type="checkbox" data-f="enabled" ${c.enabled !== false ? 'checked' : ''}>启用</label>
          <button class="btn danger sm" data-del>删除</button>
        </div>
        <div class="conn-body ${client ? 'client' : ''}">
          <div class="field"><label class="field-label">名称</label><input class="input" data-f="name" value="${esc(c.name || '')}" placeholder="SnowLuma"></div>
          <div class="field"><label class="field-label">连接 ID</label><input class="input mono" data-f="id" value="${esc(c.id || '')}" placeholder="snowluma"></div>
          <div class="field"><label class="field-label">接入方式</label><select class="select" data-f="direction"><option value="server" ${client ? '' : 'selected'}>等待平台连入（服务端 WS）</option><option value="client" ${client ? 'selected' : ''}>主动连接平台（客户端 WS）</option></select></div>
          <div class="field" data-url-field><label class="field-label">${client ? '平台 WS 地址' : '访问令牌（可留空）'}</label><input class="input" data-f="${client ? 'url' : 'access_token'}" type="${client ? 'text' : 'password'}" value="${esc(client ? (c.url || '') : (c.access_token || ''))}" placeholder="${client ? 'ws://127.0.0.1:3001' : '留空表示不鉴权'}"></div>
          <div class="field"><label class="field-label">状态</label><span class="badge ${a.self_id ? 'on' : ''}">${a.self_id ? 'QQ ' + esc(a.self_id) : '未登录'}</span></div>
        </div>
        <div class="conn-url-preview mono">${esc(endpoint || '等待填写')}</div>
      </div>`;
  }

  function updateConnRow(row) {
    const client = row.querySelector('[data-f="direction"]').value === 'client';
    const field = row.querySelector('[data-url-field]');
    const input = field.querySelector('input');
    field.querySelector('.field-label').textContent = client ? '平台 WS 地址' : '访问令牌（可留空）';
    input.dataset.f = client ? 'url' : 'access_token';
    input.type = client ? 'text' : 'password';
    input.placeholder = client ? 'ws://127.0.0.1:3001' : '留空表示不鉴权';
    row.querySelector('.conn-body').classList.toggle('client', client);
    const id = row.querySelector('[data-f="id"]').value.trim() || 'default';
    const token = client ? '' : input.value.trim();
    row.querySelector('.conn-url-preview').textContent = client ? input.value.trim() : wsEndpoint(id, token);
  }

  function collectConnections(view) {
    return $$('.conn', view).map(row => ({
      id: row.querySelector('[data-f="id"]').value.trim(),
      name: row.querySelector('[data-f="name"]').value.trim(),
      direction: row.querySelector('[data-f="direction"]').value,
      url: row.querySelector('[data-f="url"]') ? row.querySelector('[data-f="url"]').value.trim() : '',
      access_token: row.querySelector('[data-f="access_token"]') ? row.querySelector('[data-f="access_token"]').value.trim() : '',
      enabled: row.querySelector('[data-f="enabled"]').checked
    }));
  }

  async function renderPlatforms(view) {
    let p, c;
    try { [p, c] = await Promise.all([api('platforms'), api('config')]); } catch (e) { return; }
    const conns = p.connections || [];
    const active = p.active || [];
    const r = c.config.reply || {};
    view.innerHTML = `
      <div class="card" style="margin-bottom:16px">
        <div class="card-title"><h3>多 WebSocket 接入</h3><span class="tag">${active.filter(x => x.online).length}/${conns.length} 在线</span></div>
        <p class="muted" style="margin-bottom:16px">每条连接都有独立名称、ID、方向与令牌；服务端连接可通过 <span class="mono">/ws?conn=连接ID</span> 接入，多条 WS 可同时在线。</p>
        <div class="conn-list" id="connList">
          ${conns.map((x, i) => connTemplate(x, active, i)).join('')}
        </div>
        <div class="actions" style="margin-top:16px">
          <button class="btn" id="addConn">新增连接</button>
          <button class="btn primary" id="saveConns">保存并应用</button>
          <button class="btn soft" id="reconnectAll">重启全部连接</button>
        </div>
      </div>
      <div class="grid g2" style="margin-bottom:16px">
        <div class="card">
          <div class="card-title"><h3>回复规则</h3><span class="tag">Reply</span></div>
          <div class="field-grid">
            <div class="field"><label class="field-label">私聊响应</label><select class="select" id="rPriv"><option value="1" ${r.private ? 'selected' : ''}>开启</option><option value="0" ${!r.private ? 'selected' : ''}>关闭</option></select></div>
            <div class="field"><label class="field-label">群聊需 @</label><select class="select" id="rAt"><option value="1" ${r.group_at ? 'selected' : ''}>是</option><option value="0" ${!r.group_at ? 'selected' : ''}>否（全量回复）</option></select></div>
            <div class="field"><label class="field-label">插件免 @</label><select class="select" id="rCmdAny"><option value="1" ${r.group_command_any ? 'selected' : ''}>是</option><option value="0" ${!r.group_command_any ? 'selected' : ''}>否</option></select></div>
            <div class="field"><label class="field-label"># 快速对话</label><select class="select" id="rHash"><option value="1" ${r.group_hash_chat ? 'selected' : ''}>是</option><option value="0" ${!r.group_hash_chat ? 'selected' : ''}>否</option></select></div>
            <div class="field"><label class="field-label">上下文条数</label><input class="input" id="rCtx" type="number" min="2" max="50" value="${esc(r.max_context)}"></div>
            <div class="field"><label class="field-label">冷却秒数</label><input class="input" id="rCd" type="number" step="0.1" min="0" value="${esc(r.cooldown)}"></div>
          </div>
          <div class="field"><label class="field-label">群聊唤醒前缀（逗号分隔，可留空）</label><input class="input" id="rPre" value="${esc((r.prefixes || []).join(','))}" placeholder="心心念念,"></div>
          <p class="tiny">群内 <span class="mono">#内容</span> 免 @ 直接对话；<span class="mono">/指令</span> 与插件关键词默认可直接触发；普通闲聊需 @ 或前缀。</p>
          <div class="actions" style="margin-top:14px"><button class="btn primary" id="saveReply">保存规则</button></div>
        </div>
        <div class="card">
          <div class="card-title"><h3>测试发送</h3><span class="tag">OneBot API</span></div>
          <div class="field-grid">
            <div class="field"><label class="field-label">类型</label><select class="select" id="sType"><option value="private">私聊</option><option value="group">群聊</option></select></div>
            <div class="field"><label class="field-label">QQ 号 / 群号</label><input class="input" id="sTarget" placeholder="123456"></div>
          </div>
          <div class="field"><label class="field-label">内容</label><input class="input" id="sText" placeholder="测试消息"></div>
          <div class="actions"><button class="btn" id="sSend">发送测试消息</button></div>
          <p class="tiny" style="margin-top:14px">消息会经由当前主连接发送；多个平台在线时，聊天回复会自动回到消息来源平台。</p>
        </div>
      </div>
      <div class="card">
        <div class="card-title"><h3>控制台令牌</h3><span class="tag">128 位</span></div>
        <div class="copy-field">
          <input class="input mono" id="tkShow" readonly value="点击右侧按钮显示">
          <button class="btn" id="tkReveal">显示</button>
          <button class="btn danger" id="tkReset">重置</button>
        </div>
        <p class="tiny" style="margin-top:12px">重置后所有已登录控制台会话立即失效，请妥善保存新令牌。</p>
      </div>`;

    const list = $('#connList');
    const bindRow = (row) => {
      row.querySelector('[data-del]').onclick = () => row.remove();
      row.querySelector('[data-f="direction"]').onchange = () => updateConnRow(row);
      row.querySelector('[data-f="id"]').oninput = () => updateConnRow(row);
      const tokenInput = row.querySelector('input[data-f="access_token"]');
      if (tokenInput) tokenInput.oninput = () => updateConnRow(row);
    };
    $$('.conn', list).forEach(bindRow);
    $('#addConn').onclick = () => {
      const temp = document.createElement('div');
      temp.innerHTML = connTemplate({ id: 'conn-' + Math.random().toString(36).slice(2, 7), name: '', direction: 'server', access_token: '', enabled: true }, [], 0);
      const row = temp.firstElementChild;
      list.appendChild(row);
      bindRow(row);
      updateConnRow(row);
      row.scrollIntoView({ behavior: 'smooth', block: 'center' });
    };
    $('#saveConns').onclick = async (ev) => {
      const b = ev.currentTarget;
      b.disabled = true;
      b.textContent = '应用中…';
      try {
        const d = await api('platforms', { method: 'POST', body: { connections: collectConnections(view) } });
        toast('平台配置已应用', 'ok');
        renderPlatforms(view);
        paintTop(await api('overview'));
      } catch (e) { toast(e.message, 'err'); }
      finally { b.disabled = false; b.textContent = '保存并应用'; }
    };
    $('#reconnectAll').onclick = async (ev) => {
      const b = ev.currentTarget;
      b.disabled = true;
      try { await api('platforms/reconnect', { method: 'POST' }); toast('连接已重启', 'ok'); renderPlatforms(view); }
      catch (e) { toast(e.message, 'err'); }
      finally { b.disabled = false; }
    };
    $('#saveReply').onclick = async () => {
      try {
        await api('config', { method: 'POST', body: { reply: {
          private: $('#rPriv').value === '1', group_at: $('#rAt').value === '1',
          group_command_any: $('#rCmdAny').value === '1', group_hash_chat: $('#rHash').value === '1',
          max_context: parseInt(val('#rCtx')) || 12, cooldown: parseFloat(val('#rCd')) || 0,
          prefixes: val('#rPre').split(',').map(s => s.trim()).filter(Boolean)
        }}});
        toast('回复规则已保存', 'ok');
      } catch (e) { toast(e.message, 'err'); }
    };
    $('#sSend').onclick = async () => {
      try {
        await api('send', { method: 'POST', body: { type: $('#sType').value, target: val('#sTarget'), text: $('#sText').value } });
        toast('已发送', 'ok');
      } catch (e) { toast(e.message, 'err'); }
    };
    $('#tkReveal').onclick = async () => {
      try { const d = await api('token'); $('#tkShow').value = d.token; }
      catch (e) { toast(e.message, 'err'); }
    };
    $('#tkShow').onclick = async () => {
      try { await navigator.clipboard.writeText($('#tkShow').value); toast('已复制', 'ok'); }
      catch (e) { $('#tkShow').select(); document.execCommand('copy'); toast('已复制', 'ok'); }
    };
    $('#tkReset').onclick = async () => {
      if (!confirm('重置后所有控制台会话失效，确定？')) return;
      try { const d = await api('token/reset', { method: 'POST' }); $('#tkShow').value = d.token; toast('令牌已重置，请保存新令牌', 'ok'); }
      catch (e) { toast(e.message, 'err'); }
    };
  }

  async function renderPlugins(view) {
    let d;
    try { d = await api('plugins'); } catch (e) { return; }
    const list = d.plugins || [];
    const admins = Array.isArray(d.admins) ? d.admins.slice() : [];
    function renderAdmins(cur) {
      const box = $('#admList');
      if (!box) return;
      box.innerHTML = cur.length ? cur.map(a => '<span class="admin-chip">' + esc(a) + '<button data-adm="' + esc(a) + '" title="移除"><svg viewBox="0 0 24 24"><path d="M6 6l12 12M18 6L6 18" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round"/></svg></button></span>').join('') : '<span class="tiny">当前没有管理员，开启「仅管理员」后所有人都无法使用该插件</span>';
      $$('[data-adm]', box).forEach(b => {
        b.onclick = async () => {
          const next = cur.filter(x => x !== b.dataset.adm);
          try { await api('admins', { method: 'POST', body: { admins: next } }); cur.length = 0; cur.push.apply(cur, next); renderAdmins(cur); toast('已移除', 'ok'); }
          catch (e) { toast(e.message, 'err'); }
        };
      });
    }
    view.innerHTML = `
      <div class="card" style="margin-bottom:16px">
        <div style="display:flex;align-items:center;justify-content:space-between;gap:10px;flex-wrap:wrap"><b>管理员</b><span class="tiny">默认无管理员，仅列表内 QQ 可使用开启限制的插件</span></div>
        <div class="admin-row"><input class="input" id="admInput" placeholder="输入 QQ 号后回车添加" maxlength="16" inputmode="numeric"><button class="btn sm" id="admAdd">添加</button></div>
        <div class="admin-chips" id="admList"></div>
      </div>
      <div class="card" style="margin-bottom:16px">
        <div class="upload" id="drop">
          <svg viewBox="0 0 24 24"><path d="M12 3a1 1 0 0 1 .7.3l5 5a1 1 0 0 1-1.4 1.4L13 6.4V16a1 1 0 1 1-2 0V6.4L7.7 9.7A1 1 0 0 1 6.3 8.3l5-5A1 1 0 0 1 12 3ZM5 19h14a1 1 0 1 1 0 2H5a1 1 0 1 1 0-2Z"/></svg>
          <b>上传插件包（.zip）</b>
          <span class="tiny">需包含 main.py 与 m.json，可选 icon.png 与 assets/；闲置插件自动休眠，触发时自动唤醒</span>
          <input type="file" id="fileInput" accept=".zip" class="hidden">
        </div>
      </div>
      <div class="grid g2" id="pluginGrid">
        ${list.length ? list.map(p => `
          <div class="plugin-card" data-name="${esc(p.name)}">
            ${p.icon ? `<img class="plugin-icon" src="${esc(p.icon)}?t=${encodeURIComponent(SESSION)}" alt="">` : `<div class="plugin-icon">${esc((p.title || 'P')[0].toUpperCase())}</div>`}
            <div class="plugin-main">
              <div class="plugin-title"><b>${esc(p.title)}</b><span class="badge">v${esc(p.version)}</span><span class="badge ${p.enabled ? 'on' : 'off'}">${p.enabled ? '已启用' : '已停用'}</span>${p.enabled && !p.loaded ? '<span class="badge">休眠中</span>' : ''}</div>
              <div class="plugin-desc">${esc(p.description || '暂无简介')}</div>
              <div class="plugin-meta"><span>作者 ${esc(p.author)}</span><span>${p.commands.length ? '指令 ' + p.commands.map(x => '/' + esc(x)).join(' ') : '无指令'}</span><span>${esc(p.size)}</span></div>
            </div>
            <div class="plugin-ops">
              <div class="switch ${p.enabled ? 'on' : ''}" data-act="toggle"><i></i></div>
              <button class="btn sm admin-toggle ${p.admin_only ? 'on' : ''}" data-act="admin" title="仅管理员使用"><svg viewBox="0 0 24 24"><path d="M12 2 4 5v6c0 5 3.4 8.6 8 10 4.6-1.4 8-5 8-10V5l-8-3Zm0 2.2 6 2.2v4.6c0 3.8-2.5 6.6-6 7.8-3.5-1.2-6-4-6-7.8V6.4l6-2.2Zm-1 4v3H8v2h3v3h2v-3h3v-2h-3V8.2h-2Z"/></svg>仅管理员</button>
              ${Object.keys(p.config_schema || {}).length ? '<button class="btn ghost sm" data-act="config">配置</button>' : ''}
              <button class="btn danger sm" data-act="del">删除</button>
            </div>
          </div>`).join('') : '<div class="card"><div class="empty">还没有安装插件，上传一个 zip 即可安装。</div></div>'}
      </div>
      `;
    renderAdmins(admins);
    const addAdmin = async () => {
      const v = $('#admInput').value.trim();
      if (!/^\d{4,16}$/.test(v)) return toast('请输入正确的 QQ 号', 'err');
      if (admins.indexOf(v) >= 0) return toast('已经在列表里了', 'err');
      const next = admins.concat([v]);
      try { await api('admins', { method: 'POST', body: { admins: next } }); admins.length = 0; admins.push.apply(admins, next); $('#admInput').value = ''; renderAdmins(admins); toast('已添加', 'ok'); }
      catch (e) { toast(e.message, 'err'); }
    };
    $('#admAdd').onclick = addAdmin;
    $('#admInput').onkeydown = (e) => { if (e.key === 'Enter') addAdmin(); };
    const drop = $('#drop'), fi = $('#fileInput');
    drop.onclick = () => fi.click();
    fi.onchange = () => { if (fi.files[0]) upload(fi.files[0]); };
    ['dragenter', 'dragover'].forEach(ev => drop.addEventListener(ev, e => { e.preventDefault(); drop.classList.add('over'); }));
    ['dragleave', 'drop'].forEach(ev => drop.addEventListener(ev, e => { e.preventDefault(); drop.classList.remove('over'); }));
    drop.addEventListener('drop', e => { const f = e.dataTransfer.files[0]; if (f) upload(f); });
    async function upload(file) {
      const fd = new FormData();
      fd.append('file', file);
      toast('上传中…');
      try {
        const d = await api('plugins/upload', { method: 'POST', body: fd });
        toast('已安装：' + (d.title || d.name), 'ok');
        renderPlugins(view);
      } catch (e) { toast(e.message, 'err'); }
    }
    $$('#pluginGrid .plugin-card').forEach(el => {
      const name = el.dataset.name;
      $('[data-act="admin"]', el).onclick = async (ev) => {
        const on = !ev.currentTarget.classList.contains('on');
        try {
          await api('plugins/' + encodeURIComponent(name) + '/admin', { method: 'POST', body: { admin_only: on } });
          toast(on ? '已开启管理员限制' : '已关闭管理员限制', 'ok');
          renderPlugins(view);
        } catch (e) { toast(e.message, 'err'); }
      };
      $('[data-act="toggle"]', el).onclick = async (ev) => {
        const on = !ev.currentTarget.classList.contains('on');
        try {
          await api('plugins/' + encodeURIComponent(name) + '/toggle', { method: 'POST', body: { enabled: on } });
          toast(on ? '已启用' : '已停用', 'ok');
          renderPlugins(view);
        } catch (e) { toast(e.message, 'err'); }
      };
      $('[data-act="del"]', el).onclick = async () => {
        if (!confirm('确定删除插件 ' + name + '？')) return;
        try { await api('plugins/' + encodeURIComponent(name), { method: 'DELETE' }); toast('已删除', 'ok'); renderPlugins(view); }
        catch (e) { toast(e.message, 'err'); }
      };
      const cb = $('[data-act="config"]', el);
      if (cb) cb.onclick = () => pluginConfig(name);
    });
  }

  async function pluginConfig(name) {
    let d;
    try { d = await api('plugins/' + encodeURIComponent(name) + '/config'); } catch (e) { return toast(e.message, 'err'); }
    const schema = d.schema || {}, values = d.values || {};
    const fields = Object.keys(schema).map(k => {
      const v = schema[k] || {}, cur = values[k], label = v.label || k;
      if (v.type === 'bool' || v.type === 'boolean') {
        return `<div class="field"><label class="field-label">${esc(label)}</label><select class="select" data-k="${esc(k)}"><option value="1" ${cur ? 'selected' : ''}>开启</option><option value="0" ${!cur ? 'selected' : ''}>关闭</option></select></div>`;
      }
      if (v.type === 'number') {
        return `<div class="field"><label class="field-label">${esc(label)}</label><input class="input" data-k="${esc(k)}" type="number" value="${esc(cur == null ? '' : cur)}"></div>`;
      }
      return `<div class="field"><label class="field-label">${esc(label)}</label><input class="input" data-k="${esc(k)}" value="${esc(cur == null ? '' : cur)}" placeholder="${esc(v.placeholder || '')}"></div>`;
    }).join('');
    const m = modal(`
      <h3>插件配置 · ${esc(name)}</h3>
      ${fields || '<p class="muted">该插件没有可配置项</p>'}
      <div class="actions" style="margin-top:18px"><button class="btn primary" id="pcSave">保存</button><button class="btn" id="pcClose">关闭</button></div>`);
    $('#pcClose', m).onclick = closeModal;
    $('#pcSave', m).onclick = async () => {
      const out = {};
      $$('[data-k]', m).forEach(i => {
        const sch = schema[i.dataset.k] || {};
        out[i.dataset.k] = (sch.type === 'bool' || sch.type === 'boolean') ? i.value === '1' : (sch.type === 'number' ? Number(i.value) : i.value);
      });
      try {
        await api('plugins/' + encodeURIComponent(name) + '/config', { method: 'POST', body: { values: out } });
        toast('已保存', 'ok');
        closeModal();
      } catch (e) { toast(e.message, 'err'); }
    };
  }

  async function renderLogs(view) {
    view.innerHTML = `
      <div class="card">
        <div class="card-title"><h3>实时日志</h3><span class="tag">Server Stream</span><span class="spacer" style="flex:1"></span><label class="check"><input type="checkbox" id="autoScroll" checked>自动滚动</label><button class="btn ghost sm" id="clearLogView">清屏</button></div>
        <div class="log-box" id="logs"></div>
      </div>`;
    const box = $('#logs');
    const add = (it) => {
      const div = document.createElement('div');
      div.className = 'lg-' + (it.level || 'info');
      div.innerHTML = `<span class="log-time">${esc((it.t || '').slice(11))}</span>${esc(it.msg)}`;
      box.appendChild(div);
      while (box.childNodes.length > 700) box.removeChild(box.firstChild);
      if ($('#autoScroll').checked) box.scrollTop = box.scrollHeight;
    };
    try { const d = await api('logs?since=0'); (d.items || []).forEach(add); } catch (e) {}
    if (EVT) EVT.close();
    EVT = new EventSource(API('logs/stream') + '?t=' + encodeURIComponent(SESSION));
    EVT.onmessage = (e) => { try { add(JSON.parse(e.data)); } catch (err) {} };
    EVT.onerror = () => {};
    $('#clearLogView').onclick = () => { box.innerHTML = ''; };
  }

  function openDrawer() {
    $('.sidebar').classList.add('open');
    $('#drawerMask').classList.remove('hidden');
  }

  function closeDrawer() {
    $('.sidebar').classList.remove('open');
    $('#drawerMask').classList.add('hidden');
  }

  async function boot() {
    $('#loginBtn').onclick = doLogin;
    $('#tokenInput').addEventListener('keydown', e => { if (e.key === 'Enter') doLogin(); });
    $('#eyeBtn').onclick = () => { const i = $('#tokenInput'); i.type = i.type === 'password' ? 'text' : 'password'; };
    $('#logoutBtn').onclick = () => logout();
    $('#refreshBtn').onclick = () => go((location.hash || '#dashboard').slice(1));
    $('#menuBtn').onclick = openDrawer;
    $('#drawerMask').onclick = closeDrawer;
    window.addEventListener('hashchange', () => go((location.hash || '#dashboard').slice(1)));
    if (!SESSION) return showLogin();
    try {
      const d = await api('overview');
      paintTop(d);
      showApp();
      startPolling();
    } catch (e) {
      showLogin();
    }
  }

  boot();
})();
