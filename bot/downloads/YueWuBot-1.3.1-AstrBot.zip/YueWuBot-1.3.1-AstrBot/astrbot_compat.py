import asyncio
import enum
import importlib.util
import inspect
import re
import sys
import types
from pathlib import Path


class Logger:
    def __init__(self, name="astrbot"):
        self.name = name

    def _out(self, level, msg, *args):
        try:
            if args:
                msg = msg % args
            print("[%s] %s" % (level, msg), flush=True)
        except Exception:
            pass

    def info(self, msg, *args):
        self._out("INFO", msg, *args)

    def debug(self, msg, *args):
        pass

    def warning(self, msg, *args):
        self._out("WARN", msg, *args)

    warn = warning

    def error(self, msg, *args):
        self._out("ERROR", msg, *args)

    def critical(self, msg, *args):
        self._out("CRIT", msg, *args)

    def exception(self, msg, *args):
        self._out("ERROR", msg, *args)

    def success(self, msg, *args):
        self._out("OK", msg, *args)

    def getChild(self, name):
        return Logger(self.name + "." + name)

    def __getattr__(self, name):
        return lambda *a, **k: None


logger = Logger("astrbot")


class StarMetadata:
    def __init__(self, **kw):
        self.name = kw.get("name")
        self.author = kw.get("author")
        self.desc = kw.get("desc")
        self.short_desc = kw.get("short_desc")
        self.version = kw.get("version")
        self.repo = kw.get("repo")
        self.star_cls_type = kw.get("star_cls_type")
        self.module_path = kw.get("module_path")
        self.star_cls = kw.get("star_cls")
        self.module = kw.get("module")
        self.root_dir_name = kw.get("root_dir_name")
        self.reserved = kw.get("reserved", False)
        self.activated = kw.get("activated", True)
        self.config = kw.get("config")
        self.star_handler_full_names = kw.get("star_handler_full_names", [])
        self.display_name = kw.get("display_name")
        self.logo_path = kw.get("logo_path")
        self.support_platforms = kw.get("support_platforms", [])
        self.astrbot_version = kw.get("astrbot_version")
        self.i18n = kw.get("i18n", {})
        self.views = kw.get("views", [])

    @property
    def plugin_id(self):
        p_name = (self.name or "unknown").lower().replace("/", "_")
        p_author = (self.author or "unknown").lower().replace("/", "_")
        return "%s/%s" % (p_author, p_name)

    def __str__(self):
        return "Plugin %s (%s) by %s: %s" % (self.name, self.version, self.author, self.desc)

    __repr__ = __str__


star_registry = []
star_map = {}


class Star:
    author = ""
    name = ""

    def __init__(self, context, config=None):
        self.context = context
        self.config = config
        self.logger = logger.getChild(self.__class__.__name__)

    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        md = star_map.get(cls.__module__)
        if md is None:
            md = StarMetadata(star_cls_type=cls, module_path=cls.__module__)
            star_map[cls.__module__] = md
            star_registry.append(md)
        else:
            md.star_cls_type = cls
            md.module_path = cls.__module__

    async def text_to_image(self, text, return_url=True, template_name=None, umo=None):
        return text

    async def terminate(self):
        pass

    async def initialize(self):
        pass


class EventType(enum.Enum):
    OnAstrBotLoadedEvent = enum.auto()
    OnPlatformLoadedEvent = enum.auto()
    AdapterMessageEvent = enum.auto()
    OnWaitingLLMRequestEvent = enum.auto()
    OnLLMRequestEvent = enum.auto()
    OnLLMResponseEvent = enum.auto()
    OnAgentBeginEvent = enum.auto()
    OnAgentDoneEvent = enum.auto()
    OnDecoratingResultEvent = enum.auto()
    OnCallingFuncToolEvent = enum.auto()
    OnUsingLLMToolEvent = enum.auto()
    OnLLMToolRespondEvent = enum.auto()
    OnAfterMessageSentEvent = enum.auto()
    OnPluginErrorEvent = enum.auto()
    OnPluginLoadedEvent = enum.auto()
    OnPluginUnloadedEvent = enum.auto()


class HandlerFilter:
    def filter(self, event, cfg=None):
        return False


class StarHandlerMetadata:
    def __init__(self, event_type, handler_full_name, handler_name, handler_module_path,
                 handler, event_filters=None, desc="", extras_configs=None, enabled=True):
        self.event_type = event_type
        self.handler_full_name = handler_full_name
        self.handler_name = handler_name
        self.handler_module_path = handler_module_path
        self.handler = handler
        self.event_filters = event_filters if event_filters is not None else []
        self.desc = desc
        self.extras_configs = extras_configs if extras_configs is not None else {}
        self.enabled = enabled

    def __lt__(self, other):
        return self.extras_configs.get("priority", 0) < other.extras_configs.get("priority", 0)


class StarHandlerRegistry:
    def __init__(self):
        self.star_handlers_map = {}
        self._handlers = []

    def append(self, handler):
        if "priority" not in handler.extras_configs:
            handler.extras_configs["priority"] = 0
        self.star_handlers_map[handler.handler_full_name] = handler
        self._handlers.append(handler)
        self._handlers.sort(key=lambda h: -h.extras_configs["priority"])

    def get_handlers_by_event_type(self, event_type, only_activated=True, plugins_name=None):
        out = []
        for h in self._handlers:
            if h.event_type != event_type or not h.enabled:
                continue
            if only_activated:
                plugin = star_map.get(h.handler_module_path)
                if not (plugin and plugin.activated):
                    continue
            out.append(h)
        return out

    def get_handler_by_full_name(self, full_name):
        return self.star_handlers_map.get(full_name)

    def get_handlers_by_module_name(self, module_name):
        return [h for h in self._handlers if h.handler_module_path == module_name]

    def clear(self):
        self.star_handlers_map.clear()
        self._handlers = []

    def remove(self, handler):
        self.star_handlers_map.pop(handler.handler_full_name, None)
        self._handlers = [h for h in self._handlers if h != handler]

    def __iter__(self):
        return iter(self._handlers)

    def __len__(self):
        return len(self._handlers)


star_handlers_registry = StarHandlerRegistry()


class GreedyStr(str):
    pass


class CommandFilter(HandlerFilter):
    def __init__(self, command_name, alias=None, handler_md=None, parent_command_names=None):
        self.command_name = str(command_name)
        self.alias = set(alias) if alias else set()
        self.parent_command_names = parent_command_names if parent_command_names is not None else [""]
        self.handler_md = handler_md
        self.handler_params = {}
        self.custom_filter_list = []
        self._cmpl_cmd_names = None
        if handler_md:
            self.init_handler_md(handler_md)

    def init_handler_md(self, handle_md):
        self.handler_md = handle_md
        try:
            sig = inspect.signature(handle_md.handler)
            self.handler_params = {}
            idx = 0
            for k, v in sig.parameters.items():
                if idx < 2:
                    idx += 1
                    continue
                self.handler_params[k] = v.default if v.default != inspect.Parameter.empty else str
        except Exception:
            self.handler_params = {}

    def get_handler_md(self):
        return self.handler_md

    def add_custom_filter(self, custom_filter):
        self.custom_filter_list.append(custom_filter)

    def custom_filter_ok(self, event, cfg=None):
        for f in self.custom_filter_list:
            try:
                if not f.filter(event, cfg):
                    return False
            except Exception:
                return False
        return True

    def get_complete_command_names(self):
        if self._cmpl_cmd_names is not None:
            return self._cmpl_cmd_names
        parents = self.parent_command_names or [""]
        self._cmpl_cmd_names = [
            ("%s %s" % (p, c)) if p else c
            for c in [self.command_name] + [str(a) for a in self.alias]
            for p in parents
        ]
        return self._cmpl_cmd_names

    def equals(self, message_str):
        return message_str in self.get_complete_command_names()

    def filter(self, event, cfg=None):
        if not getattr(event, "is_at_or_wake_command", False):
            return False
        if not self.custom_filter_ok(event, cfg):
            return False
        message_str = re.sub(r"\s+", " ", (event.get_message_str() or "").strip())
        for full_cmd in self.get_complete_command_names():
            if message_str == full_cmd or message_str.startswith(full_cmd + " "):
                return True
        return False

    def validate_and_convert_params(self, params):
        result = {}
        items = list(self.handler_params.items())
        for i, (name, default) in enumerate(items):
            if default is GreedyStr:
                result[name] = " ".join([str(x) for x in params[i:]])
            elif i < len(params):
                result[name] = params[i]
            else:
                result[name] = None if default is str else default
        return result


class CommandGroupFilter:
    def __init__(self, group_name, alias=None):
        self.group_name = str(group_name)
        self.alias = set(alias) if alias else set()
        self.sub_command_filters = []
        self.custom_filter_list = []

    def add_sub_command_filter(self, f):
        self.sub_command_filters.append(f)

    def get_complete_command_names(self):
        return [self.group_name] + [str(a) for a in self.alias]

    def add_custom_filter(self, f):
        self.custom_filter_list.append(f)


class RegisteringCommandable:
    def __init__(self, parent_group, cmd=None):
        self.parent_group = parent_group
        self.cmd = cmd

    def command(self, sub_command, alias=None, **kwargs):
        return register_command(sub_command, alias, self, **kwargs)


class RegexFilter(HandlerFilter):
    def __init__(self, regex):
        self.regex = re.compile(regex)
        self.regex_str = self.regex.pattern

    def filter(self, event, cfg=None):
        return bool(self.regex.search((event.get_message_str() or "").strip()))


class PermissionType(enum.Enum):
    ADMIN = "admin"
    MEMBER = "member"


class PermissionTypeFilter(HandlerFilter):
    def __init__(self, permission_type, raise_error=True):
        self.permission_type = permission_type
        self.raise_error = raise_error

    def filter(self, event, cfg=None):
        if self.permission_type == PermissionType.ADMIN:
            return bool(event.is_admin())
        return True


class EventMessageType(enum.Enum):
    GROUP_MESSAGE = 1
    PRIVATE_MESSAGE = 2
    ALL = 3


class EventMessageTypeFilter(HandlerFilter):
    def __init__(self, message_type):
        self.message_type = message_type

    def filter(self, event, cfg=None):
        if self.message_type == EventMessageType.ALL:
            return True
        is_group = not event.is_private_chat()
        if self.message_type == EventMessageType.GROUP_MESSAGE:
            return is_group
        return not is_group


class CustomFilter:
    def filter(self, event, cfg=None):
        return True

    def __and__(self, other):
        return CustomFilterAnd(self, other)

    def __or__(self, other):
        return CustomFilterOr(self, other)


class CustomFilterAnd(CustomFilter):
    def __init__(self, a, b):
        self.a = a
        self.b = b

    def filter(self, event, cfg=None):
        return self.a.filter(event, cfg) and self.b.filter(event, cfg)


class CustomFilterOr(CustomFilter):
    def __init__(self, a, b):
        self.a = a
        self.b = b

    def filter(self, event, cfg=None):
        return self.a.filter(event, cfg) or self.b.filter(event, cfg)


def get_handler_full_name(awaitable):
    return "%s_%s" % (awaitable.__module__, awaitable.__name__)


def get_handler_or_create(handler, event_type, dont_add=False, **kwargs):
    full_name = get_handler_full_name(handler)
    md = star_handlers_registry.get_handler_by_full_name(full_name)
    if md:
        return md
    md = StarHandlerMetadata(
        event_type=event_type,
        handler_full_name=full_name,
        handler_name=handler.__name__,
        handler_module_path=handler.__module__,
        handler=handler,
        event_filters=[],
        desc=(handler.__doc__ or "").strip() if handler.__doc__ else "",
        extras_configs=dict(kwargs),
    )
    if kwargs.get("desc"):
        md.desc = kwargs["desc"]
    if not dont_add:
        star_handlers_registry.append(md)
    return md


def register_star(name, author, desc, version, repo=None):
    def decorator(cls):
        md = star_map.get(cls.__module__)
        if md is None:
            md = StarMetadata(name=name, author=author, desc=desc, version=version, repo=repo)
            star_map[cls.__module__] = md
            star_registry.append(md)
        else:
            md.name = name
            md.author = author
            md.desc = desc
            md.version = version
            md.repo = repo
        return cls
    return decorator


def register_command(command_name=None, alias=None, sub_command=None, **kwargs):
    if isinstance(command_name, RegisteringCommandable):
        parent = command_name
        f = CommandFilter(sub_command, alias, None,
                          parent_command_names=parent.parent_group.get_complete_command_names())
        parent.parent_group.add_sub_command_filter(f)
    else:
        f = CommandFilter(command_name, alias, None) if command_name else None

    def decorator(awaitable):
        md = get_handler_or_create(awaitable, EventType.AdapterMessageEvent, **kwargs)
        if f is not None:
            f.init_handler_md(md)
            md.event_filters.append(f)
        return awaitable
    return decorator


def register_command_group(command_group_name=None, alias=None, **kwargs):
    grp = CommandGroupFilter(command_group_name, alias)

    def decorator(awaitable):
        return RegisteringCommandable(grp, command_group_name)
    return decorator


def register_regex(regex, **kwargs):
    f = RegexFilter(regex)

    def decorator(awaitable):
        md = get_handler_or_create(awaitable, EventType.AdapterMessageEvent, **kwargs)
        md.event_filters.append(f)
        return awaitable
    return decorator


def register_permission_type(permission_type, raise_error=True, **kwargs):
    f = PermissionTypeFilter(permission_type, raise_error)

    def decorator(awaitable):
        md = get_handler_or_create(awaitable, EventType.AdapterMessageEvent, **kwargs)
        md.event_filters.append(f)
        return awaitable
    return decorator


def register_event_message_type(message_type, **kwargs):
    f = EventMessageTypeFilter(message_type)

    def decorator(awaitable):
        md = get_handler_or_create(awaitable, EventType.AdapterMessageEvent, **kwargs)
        md.event_filters.append(f)
        return awaitable
    return decorator


def register_custom_filter(custom_type_filter, *args, **kwargs):
    cls = custom_type_filter
    obj = cls() if isinstance(cls, type) else cls

    def decorator(awaitable):
        md = get_handler_or_create(awaitable, EventType.AdapterMessageEvent, **kwargs)
        for f in md.event_filters:
            if isinstance(f, CommandFilter):
                f.add_custom_filter(obj)
        return awaitable
    return decorator


def _hook_register(event_type):
    def deco(*dargs, **dkwargs):
        def decorator(awaitable):
            if callable(awaitable):
                get_handler_or_create(awaitable, event_type, **dkwargs)
                return awaitable
            return awaitable
        if len(dargs) == 1 and callable(dargs[0]) and not dkwargs:
            return decorator(dargs[0])
        return decorator
    return deco


register_on_astrbot_loaded = _hook_register(EventType.OnAstrBotLoadedEvent)
register_on_platform_loaded = _hook_register(EventType.OnPlatformLoadedEvent)
register_after_message_sent = _hook_register(EventType.OnAfterMessageSentEvent)
register_on_decorating_result = _hook_register(EventType.OnDecoratingResultEvent)
register_on_llm_request = _hook_register(EventType.OnLLMRequestEvent)
register_on_llm_response = _hook_register(EventType.OnLLMResponseEvent)
register_on_agent_begin = _hook_register(EventType.OnAgentBeginEvent)
register_on_agent_done = _hook_register(EventType.OnAgentDoneEvent)
register_on_using_llm_tool = _hook_register(EventType.OnUsingLLMToolEvent)
register_on_llm_tool_respond = _hook_register(EventType.OnLLMToolRespondEvent)
register_on_waiting_llm_request = _hook_register(EventType.OnWaitingLLMRequestEvent)
register_on_plugin_error = _hook_register(EventType.OnPluginErrorEvent)
register_on_plugin_loaded = _hook_register(EventType.OnPluginLoadedEvent)
register_on_plugin_unloaded = _hook_register(EventType.OnPluginUnloadedEvent)
register_llm_tool = _hook_register(EventType.OnCallingFuncToolEvent)
register_agent = _hook_register(EventType.OnAgentBeginEvent)
register_button_action = _hook_register(EventType.AdapterMessageEvent)


class PlatformAdapterType(enum.Enum):
    ALL = "all"
    ONEBOT_V11 = "onebot_v11"


class PlatformAdapterTypeFilter(HandlerFilter):
    def __init__(self, adapter_type):
        self.adapter_type = adapter_type

    def filter(self, event, cfg=None):
        return True


def register_platform_adapter_type(adapter_type, **kwargs):
    f = PlatformAdapterTypeFilter(adapter_type)

    def decorator(awaitable):
        md = get_handler_or_create(awaitable, EventType.AdapterMessageEvent, **kwargs)
        md.event_filters.append(f)
        return awaitable
    return decorator


class ButtonActionFilter(HandlerFilter):
    def __init__(self, action):
        self.action = action

    def filter(self, event, cfg=None):
        return False


class Component:
    def __init__(self, *a, **kw):
        self.text = str(kw.get("text") or (a[0] if a else "") or "")

    def __str__(self):
        return self.text


class Plain(Component):
    pass


class Image(Component):
    def __init__(self, *a, **kw):
        Component.__init__(self, *a, **kw)
        self.file = str(kw.get("file") or (a[0] if a else "") or "")

    @classmethod
    def fromURL(cls, url, **kw):
        return cls(file=url)

    @classmethod
    def fromFileSystem(cls, path, **kw):
        return cls(file=str(path))

    @classmethod
    def fromBase64(cls, b64, **kw):
        return cls(file="base64://" + str(b64))


class At(Component):
    def __init__(self, *a, **kw):
        Component.__init__(self, *a, **kw)
        self.qq = str(kw.get("qq") or "")


class AtAll(Component):
    pass


class Face(Component):
    def __init__(self, *a, **kw):
        Component.__init__(self, *a, **kw)
        self.id = kw.get("id")


class Reply(Component):
    def __init__(self, *a, **kw):
        Component.__init__(self, *a, **kw)
        self.id = kw.get("id")


class File(Component):
    def __init__(self, *a, **kw):
        Component.__init__(self, *a, **kw)
        self.name = kw.get("name", "")
        self.file = kw.get("file", "")


class Record(Component):
    def __init__(self, *a, **kw):
        Component.__init__(self, *a, **kw)
        self.file = kw.get("file", "")


class Video(Component):
    def __init__(self, *a, **kw):
        Component.__init__(self, *a, **kw)
        self.file = kw.get("file", "")


class Node(Component):
    def __init__(self, *a, **kw):
        Component.__init__(self, *a, **kw)
        self.content = kw.get("content", [])


class Nodes(Component):
    pass


class Poke(Component):
    pass


class Json(Component):
    pass


class RPS(Component):
    pass


class Dice(Component):
    pass


class Shake(Component):
    pass


class Anonymous(Component):
    pass


class Contact(Component):
    pass


class Location(Component):
    pass


class Music(Component):
    pass


class Forward(Component):
    pass


class Xml(Component):
    pass


class MFace(Component):
    pass


class EventResultType(enum.Enum):
    STOP = 0
    CONTINUE = 1


class ResultContentType(enum.Enum):
    GENERAL_RESULT = 0
    LLM_RESULT = 1


class MessageChain:
    def __init__(self, chain=None, **kw):
        self.chain = list(chain or [])
        self.use_t2i_ = None
        self.type = EventResultType.CONTINUE
        self.result_content_type = ResultContentType.GENERAL_RESULT
        self._result = None

    def message(self, text):
        self.chain.append(Plain(str(text)))
        return self

    def at(self, name, qq=""):
        self.chain.append(At(qq=str(qq)))
        return self

    def at_all(self):
        self.chain.append(AtAll())
        return self

    def error(self, message):
        return self.message(message)

    def url_image(self, url):
        self.chain.append(Image.fromURL(url))
        return self

    def file_image(self, path):
        self.chain.append(Image.fromFileSystem(path))
        return self

    def base64_image(self, b64):
        self.chain.append(Image.fromBase64(b64))
        return self

    def use_t2i(self, use):
        self.use_t2i_ = bool(use)
        return self

    def use_markdown(self, use=True):
        return self

    def get_plain_text(self, with_other_comps_mark=False):
        return "".join(str(c) for c in self.chain)

    def squash_plain(self):
        return self

    def derive(self, chain=None):
        return MessageChain(chain if chain is not None else list(self.chain))

    def __str__(self):
        return self.get_plain_text()


class MessageEventResult(MessageChain):
    def stop_event(self):
        self.type = EventResultType.STOP
        return self

    def continue_event(self):
        self.type = EventResultType.CONTINUE
        return self

    def is_stopped(self):
        return self.type == EventResultType.STOP

    def set_result_content_type(self, typ):
        self.result_content_type = typ
        return self

    def is_llm_result(self):
        return self.result_content_type == ResultContentType.LLM_RESULT

    def is_model_result(self):
        return self.is_llm_result()

    def set_async_stream(self, stream):
        return self


class CommandResult(MessageEventResult):
    pass


class MessageType(enum.Enum):
    GROUP_MESSAGE = 1
    FRIEND_MESSAGE = 2
    GUILD_MESSAGE = 3
    OTHER_MESSAGE = 4


class MessageMember:
    def __init__(self, user_id="", nickname=""):
        self.user_id = str(user_id)
        self.nickname = nickname


class AstrBotMessage:
    def __init__(self):
        self.message = []
        self.message_str = ""
        self.sender = MessageMember()
        self.type = MessageType.OTHER_MESSAGE
        self.group_id = ""
        self.self_id = ""


class PlatformMetadata:
    def __init__(self, name="onebot", description="", id="onebot"):
        self.name = name
        self.description = description
        self.id = id


class Platform:
    pass


class Provider:
    pass


class ProviderMetaData:
    pass


class Personality:
    pass


def register_platform_adapter(*a, **k):
    def deco(cls):
        return cls
    return deco


class AstrBotConfig(dict):
    def __init__(self, *a, **kw):
        dict.__init__(self, *a, **kw)

    def __getattr__(self, name):
        return self.get(name)

    def save_config(self):
        pass


class StarTools:
    def __init__(self, bot=None):
        self._bot = bot

    def get_data_dir(self):
        return ""

    def get_plugin_data_dir(self):
        return ""

    def get_config(self, *a, **k):
        return AstrBotConfig()

    def kv_get(self, *a, **k):
        return None

    def kv_set(self, *a, **k):
        pass

    def register_llm_tool(self, *a, **k):
        pass


class Context:
    def __init__(self, bot=None):
        self._bot = bot
        self.config = AstrBotConfig()
        self.plugin_manager = None
        self.provider_manager = None
        self.platform_manager = None
        self.html_renderer = None
        self.registered_web_apis = []
        self.star_tools = StarTools(bot)

    def get_config(self, *a, **k):
        return self.config

    def get_llm_tool_manager(self):
        return self

    def get_platform(self, *a, **k):
        return None

    def get_using_provider(self, *a, **k):
        return None

    def get_provider_by_id(self, *a, **k):
        return None

    def get_all_providers(self, *a, **k):
        return []

    def register_provider(self, *a, **k):
        pass

    def activate_llm_tool(self, *a, **k):
        pass

    def register_llm_tool(self, *a, **k):
        pass

    def unregister_llm_tool(self, *a, **k):
        pass

    def get_registered_web_apis(self):
        return self.registered_web_apis

    def register_web_api(self, *a, **k):
        pass

    def register_routes(self, *a, **k):
        pass

    def get_event_queue(self):
        return None

    def get_db(self):
        return None

    def get_default_persona(self):
        return Personality()

    def send_message(self, *a, **k):
        return None


class NoopLLM:
    async def generate(self, *a, **k):
        return ""


class AstrMessageEvent:
    def __init__(self, ctx=None, cmd="", args=""):
        self._ctx = ctx
        self._cmd = str(cmd or "")
        self._args = str(args or "")
        self.is_at_or_wake_command = True
        self.is_wake_up = True
        self._result = None
        self._extra = {}
        self._platform = "onebot_v11"
        self.message_obj = AstrBotMessage()
        self.session = None
        self._sender_id = str(getattr(ctx, "user_id", "") or "")
        self._sender_name = str(getattr(ctx, "sender", "") or "")
        self._group_id = str(getattr(ctx, "group_id", "") or "")
        self._text = (("/" + self._cmd + (" " + self._args if self._args else "")) if self._cmd else "")
        self.message_obj.message_str = self._text
        self.message_obj.sender = MessageMember(self._sender_id, self._sender_name)
        self.message_obj.group_id = self._group_id
        self.message_obj.type = MessageType.GROUP_MESSAGE if self._group_id else MessageType.FRIEND_MESSAGE

    def get_sender_id(self):
        return self._sender_id

    def get_sender_name(self):
        return self._sender_name

    def get_group_id(self):
        return self._group_id

    def get_message_str(self):
        return self._text

    def get_message_outline(self):
        return self._text

    def get_message(self):
        return [Plain(self._args)] if self._args else []

    def get_messages(self):
        return self.get_message()

    def get_platform_name(self):
        return self._platform

    def get_platform_id(self):
        return self._platform

    def get_session_id(self):
        return (self._group_id or self._sender_id)

    def get_unified_msg_origin(self):
        return "onebot_v11:%s:%s" % ("group" if self._group_id else "private", self.get_session_id())

    def is_private_chat(self):
        return not bool(self._group_id)

    def is_group_message(self):
        return bool(self._group_id)

    def is_admin(self):
        if not self._ctx:
            return False
        try:
            return bool(self._ctx.bot.plugins.is_admin(self._sender_id))
        except Exception:
            return False

    def is_at_or_wake(self):
        return True

    def is_wake(self):
        return True

    def plain_result(self, text):
        return MessageEventResult().message(str(text))

    def chain_result(self, chain):
        return MessageEventResult(chain)

    def image_result(self, path_or_url):
        return MessageEventResult().file_image(path_or_url)

    def make_result(self):
        return MessageEventResult()

    def request_llm(self, *a, **k):
        return NoopLLM()

    def get_config(self, *a, **k):
        return AstrBotConfig()

    def set_result(self, result):
        self._result = result
        return self

    def get_result(self):
        return self._result

    def set_extra(self, key, value=None):
        self._extra[key] = value

    def get_extra(self, key=None, default=None):
        if key is None:
            return self._extra
        return self._extra.get(key, default)

    def stop_event(self):
        return self

    def continue_event(self):
        return self

    def is_stopped(self):
        return False

    def should_stop(self):
        return False

    def get_bot(self):
        return self._ctx.bot if self._ctx else None

    async def send(self, *a, **k):
        return None

    def __getattr__(self, name):
        return lambda *a, **k: None


def _install_modules():
    def mod(name):
        m = types.ModuleType(name)
        sys.modules[name] = m
        return m

    root = mod("astrbot")
    root.logger = logger
    root.__path__ = []
    root.__version__ = "4.0.0"

    core = mod("astrbot.core")
    core.logger = logger
    core.__path__ = []
    core.html_renderer = types.SimpleNamespace()

    cfgmod = mod("astrbot.core.config")
    cfgmod.__path__ = []
    cfgmod.AstrBotConfig = AstrBotConfig
    cfgac = mod("astrbot.core.config.astrbot_config")
    cfgac.AstrBotConfig = AstrBotConfig

    logmod = mod("astrbot.core.log")
    logmod.LogManager = types.SimpleNamespace(get_plugin_logger=lambda n: logger)

    msg = mod("astrbot.core.message")
    msg.__path__ = []
    mer = mod("astrbot.core.message.message_event_result")
    mer.MessageEventResult = MessageEventResult
    mer.MessageChain = MessageChain
    mer.CommandResult = CommandResult
    mer.EventResultType = EventResultType
    mer.ResultContentType = ResultContentType

    plat = mod("astrbot.core.platform")
    plat.__path__ = []
    plat.AstrMessageEvent = AstrMessageEvent
    plat.Platform = Platform
    plat.AstrBotMessage = AstrBotMessage
    plat.MessageMember = MessageMember
    plat.MessageType = MessageType
    plat.PlatformMetadata = PlatformMetadata
    for k, v in [("astrbot.core.platform.astr_message_event", {"AstrMessageEvent": AstrMessageEvent}),
                 ("astrbot.core.platform.message_type", {"MessageType": MessageType}),
                 ("astrbot.core.platform.register", {"register_platform_adapter": register_platform_adapter})]:
        m = mod(k)
        for kk, vv in v.items():
            setattr(m, kk, vv)

    st = mod("astrbot.core.star")
    st.__path__ = []
    st.Context = Context
    st.Star = Star
    st.StarTools = StarTools
    st.star_map = star_map
    st.star_registry = star_registry
    st.StarMetadata = StarMetadata

    starmod = mod("astrbot.core.star.star")
    starmod.StarMetadata = StarMetadata
    starmod.star_map = star_map
    starmod.star_registry = star_registry

    basemod = mod("astrbot.core.star.base")
    basemod.Star = Star

    sh = mod("astrbot.core.star.star_handler")
    sh.EventType = EventType
    sh.StarHandlerMetadata = StarHandlerMetadata
    sh.StarHandlerRegistry = StarHandlerRegistry
    sh.star_handlers_registry = star_handlers_registry

    ctxmod = mod("astrbot.core.star.context")
    ctxmod.Context = Context

    toolsmod = mod("astrbot.core.star.star_tools")
    toolsmod.StarTools = StarTools

    confmod = mod("astrbot.core.star.config")
    confmod.AstrBotConfig = AstrBotConfig

    filt = mod("astrbot.core.star.filter")
    filt.__path__ = []
    filt.HandlerFilter = HandlerFilter
    filt.AstrBotConfig = AstrBotConfig
    filt.AstrMessageEvent = AstrMessageEvent
    filt.MessageType = MessageType
    for k, v in [
        ("astrbot.core.star.filter.command", {"CommandFilter": CommandFilter, "GreedyStr": GreedyStr,
                                               "RegisteringCommandable": RegisteringCommandable}),
        ("astrbot.core.star.filter.command_group", {"CommandGroupFilter": CommandGroupFilter}),
        ("astrbot.core.star.filter.regex", {"RegexFilter": RegexFilter}),
        ("astrbot.core.star.filter.permission", {"PermissionType": PermissionType,
                                                  "PermissionTypeFilter": PermissionTypeFilter}),
        ("astrbot.core.star.filter.event_message_type", {"EventMessageType": EventMessageType,
                                                          "EventMessageTypeFilter": EventMessageTypeFilter}),
        ("astrbot.core.star.filter.custom_filter", {"CustomFilter": CustomFilter,
                                                     "CustomFilterAnd": CustomFilterAnd,
                                                     "CustomFilterOr": CustomFilterOr}),
        ("astrbot.core.star.filter.platform_adapter_type", {"PlatformAdapterType": PlatformAdapterType,
                                                             "PlatformAdapterTypeFilter": PlatformAdapterTypeFilter}),
        ("astrbot.core.star.filter.button_action", {"ButtonActionFilter": ButtonActionFilter}),
    ]:
        m = mod(k)
        for kk, vv in v.items():
            setattr(m, kk, vv)

    reg_funcs = {
        "register_star": register_star,
        "get_handler_full_name": get_handler_full_name,
        "get_handler_or_create": get_handler_or_create,
        "register_command": register_command,
        "register_command_group": register_command_group,
        "register_regex": register_regex,
        "register_permission_type": register_permission_type,
        "register_event_message_type": register_event_message_type,
        "register_custom_filter": register_custom_filter,
        "register_platform_adapter_type": register_platform_adapter_type,
        "register_llm_tool": register_llm_tool,
        "register_agent": register_agent,
        "register_button_action": register_button_action,
        "register_after_message_sent": register_after_message_sent,
        "register_on_astrbot_loaded": register_on_astrbot_loaded,
        "register_on_platform_loaded": register_on_platform_loaded,
        "register_on_decorating_result": register_on_decorating_result,
        "register_on_llm_request": register_on_llm_request,
        "register_on_llm_response": register_on_llm_response,
        "register_on_agent_begin": register_on_agent_begin,
        "register_on_agent_done": register_on_agent_done,
        "register_on_using_llm_tool": register_on_using_llm_tool,
        "register_on_llm_tool_respond": register_on_llm_tool_respond,
        "register_on_waiting_llm_request": register_on_waiting_llm_request,
        "register_on_plugin_error": register_on_plugin_error,
        "register_on_plugin_loaded": register_on_plugin_loaded,
        "register_on_plugin_unloaded": register_on_plugin_unloaded,
        "register_platform_adapter": register_platform_adapter,
    }
    reg = mod("astrbot.core.star.register")
    reg.__path__ = []
    for k, v in reg_funcs.items():
        setattr(reg, k, v)

    rs = mod("astrbot.core.star.register.star")
    rs.register_star = register_star
    rs.StarMetadata = StarMetadata
    rs.star_map = star_map

    rsh = mod("astrbot.core.star.register.star_handler")
    for k, v in reg_funcs.items():
        setattr(rsh, k, v)

    api = mod("astrbot.api")
    api.__path__ = []
    api.logger = logger

    apis = mod("astrbot.api.star")
    apis.Context = Context
    apis.Star = Star
    apis.StarTools = StarTools
    apis.register = register_star
    apis.AstrBotConfig = AstrBotConfig

    apie = mod("astrbot.api.event")
    apie.__path__ = []
    apie.AstrMessageEvent = AstrMessageEvent
    apie.MessageEventResult = MessageEventResult
    apie.MessageChain = MessageChain

    apief = mod("astrbot.api.event.filter")
    apie.filter = apief
    for k, v in [
        ("command", register_command), ("command_group", register_command_group),
        ("regex", register_regex), ("permission_type", register_permission_type),
        ("event_message_type", register_event_message_type),
        ("custom_filter", register_custom_filter),
        ("platform_adapter_type", register_platform_adapter_type),
        ("llm_tool", register_llm_tool), ("on_astrbot_loaded", register_on_astrbot_loaded),
        ("on_platform_loaded", register_on_platform_loaded),
        ("after_message_sent", register_after_message_sent),
        ("on_decorating_result", register_on_decorating_result),
        ("on_llm_request", register_on_llm_request),
        ("on_llm_response", register_on_llm_response),
        ("on_agent_begin", register_on_agent_begin), ("on_agent_done", register_on_agent_done),
        ("on_using_llm_tool", register_on_using_llm_tool),
        ("on_llm_tool_respond", register_on_llm_tool_respond),
        ("on_waiting_llm_request", register_on_waiting_llm_request),
        ("on_plugin_error", register_on_plugin_error),
        ("on_plugin_loaded", register_on_plugin_loaded),
        ("on_plugin_unloaded", register_on_plugin_unloaded),
        ("button_action", register_button_action),
    ]:
        setattr(apief, k, v)
    apief.EventMessageType = EventMessageType
    apief.EventMessageTypeFilter = EventMessageTypeFilter
    apief.PermissionType = PermissionType
    apief.PermissionTypeFilter = PermissionTypeFilter
    apief.PlatformAdapterType = PlatformAdapterType
    apief.PlatformAdapterTypeFilter = PlatformAdapterTypeFilter
    apief.CustomFilter = CustomFilter
    apief.ButtonActionFilter = ButtonActionFilter

    comps = mod("astrbot.api.message_components")
    for k, v in list(globals().items()):
        if isinstance(v, type) and v.__module__ == __name__ and issubclass(v, Component):
            setattr(comps, k, v)

    apim = mod("astrbot.api.all")
    apim.AstrBotConfig = AstrBotConfig
    apim.logger = logger
    apim.html_renderer = core.html_renderer
    apim.Star = Star
    apim.Context = Context
    apim.StarTools = StarTools
    apim.register = register_star
    apim.command = register_command
    apim.command_group = register_command_group
    apim.regex = register_regex
    apim.event_message_type = register_event_message_type
    apim.permission_type = register_permission_type
    apim.platform_adapter_type = register_platform_adapter_type
    apim.llm_tool = register_llm_tool
    apim.MessageEventResult = MessageEventResult
    apim.MessageChain = MessageChain
    apim.CommandResult = CommandResult
    apim.EventResultType = EventResultType
    apim.ResultContentType = ResultContentType
    apim.AstrMessageEvent = AstrMessageEvent
    apim.Platform = Platform
    apim.AstrBotMessage = AstrBotMessage
    apim.MessageMember = MessageMember
    apim.MessageType = MessageType
    apim.PlatformMetadata = PlatformMetadata
    apim.Provider = Provider
    apim.ProviderMetaData = ProviderMetaData
    apim.Personality = Personality
    apim.register_platform_adapter = register_platform_adapter
    apim.EventMessageType = EventMessageType
    apim.EventMessageTypeFilter = EventMessageTypeFilter
    apim.PlatformAdapterType = PlatformAdapterType
    apim.PlatformAdapterTypeFilter = PlatformAdapterTypeFilter
    for k, v in list(globals().items()):
        if isinstance(v, type) and v.__module__ == __name__ and issubclass(v, Component):
            setattr(apim, k, v)

    for k in ("astrbot.api.provider", "astrbot.api.platform", "astrbot.api.util", "astrbot.api.web"):
        m = mod(k)
        m.__path__ = []
    mod("astrbot.core.provider").Provider = Provider
    mod("astrbot.core.db").__path__ = []
    dbpo = mod("astrbot.core.db.po")
    dbpo.Personality = Personality
    provreg = mod("astrbot.core.provider.register")
    provreg.llm_tools = types.SimpleNamespace()
    utilsmod = mod("astrbot.core.utils")
    utilsmod.__path__ = []


_install_modules()


def _read_metadata(d):
    out = {}
    for fn in ("metadata.yaml", "metadata.yml"):
        f = d / fn
        if not f.is_file():
            continue
        try:
            for line in f.read_text("utf-8").splitlines():
                line = line.rstrip()
                if not line or line.lstrip().startswith("#") or ":" not in line:
                    continue
                k, v = line.split(":", 1)
                k = k.strip()
                v = v.strip().strip('"').strip("'")
                if k and v:
                    out[k] = v
        except Exception:
            pass
        break
    return out


def _describe_commands(d):
    out = []
    try:
        src = (d / "main.py").read_text("utf-8")
    except Exception:
        return out
    for m in re.finditer(r"(?:filter\.)?command(?:_group)?\s*\(\s*[\"']([^\"']+)[\"']", src):
        n = m.group(1).strip()
        if n and n not in out:
            out.append(n)
    return out


def describe(d):
    meta = _read_metadata(d)
    return {
        "name": d.name,
        "title": meta.get("display_name") or meta.get("name") or d.name,
        "desc": meta.get("desc") or "AstrBot 格式插件",
        "version": meta.get("version") or "1.0.0",
        "author": meta.get("author") or "-",
        "commands": _describe_commands(d),
    }


def load_plugin(d):
    mname = "data.plugins.%s.main" % d.name
    prefix = "data.plugins.%s" % d.name
    for k in [k for k in list(sys.modules) if k == prefix or k.startswith(prefix + ".")]:
        sys.modules.pop(k, None)
    before = set(star_map.keys())
    hbefore = set(star_handlers_registry.star_handlers_map.keys())
    spec = importlib.util.spec_from_file_location(mname, str(d / "main.py"))
    if spec is None or spec.loader is None:
        raise RuntimeError("main.py 无法加载")
    mod = importlib.util.module_from_spec(spec)
    sys.modules[mname] = mod
    old = sys.path[:]
    sys.path.insert(0, str(d))
    try:
        spec.loader.exec_module(mod)
    finally:
        sys.path[:] = old

    meta = star_map.get(mname)
    if meta is None:
        for k in set(star_map.keys()) - before:
            meta = star_map[k]
            break
    inst = None
    main_mod = sys.modules.get("__main__")
    context = Context(getattr(main_mod, "bot", None))
    if meta is not None and meta.star_cls_type is not None:
        try:
            inst = meta.star_cls_type(context)
        except TypeError:
            inst = meta.star_cls_type()
        meta.star_cls = inst
        meta.module = mod
        meta.root_dir_name = d.name
        info = describe(d)
        meta.name = meta.name or info["title"]
        meta.author = meta.author or info["author"]
        meta.desc = meta.desc or info["desc"]
        meta.version = meta.version or info["version"]

    new_handlers = set(star_handlers_registry.star_handlers_map.keys()) - hbefore
    handlers = {}
    for h in star_handlers_registry:
        if h.handler_module_path != mname and h.handler_full_name not in new_handlers:
            continue
        for f in h.event_filters:
            if isinstance(f, CommandFilter):
                for n in f.get_complete_command_names():
                    key = n.strip().split(" ")[0].lower()
                    handlers[key] = {"md": h, "filter": f}
            elif isinstance(f, RegexFilter):
                handlers.setdefault("__regex__", []).append({"md": h, "filter": f})
    return mod, inst, handlers, mname


def unload(mname):
    prefix = mname.rsplit(".", 1)[0]
    for k in [k for k in list(sys.modules) if k == prefix or k.startswith(prefix + ".")]:
        sys.modules.pop(k, None)
    md = star_map.pop(mname, None)
    if md is not None:
        try:
            star_registry.remove(md)
        except ValueError:
            pass
    for h in list(star_handlers_registry.get_handlers_by_module_name(mname)):
        star_handlers_registry.remove(h)


async def invoke(mod, inst, handler, ctx, cmd, args):
    event = AstrMessageEvent(ctx, cmd, args)
    md = handler["md"]
    fn = md.handler
    cf = handler.get("filter")
    kw = {}
    parts = [x for x in str(args or "").split(" ") if x != ""]
    if isinstance(cf, CommandFilter) and cf.handler_params:
        kw = cf.validate_and_convert_params(parts)
    bound = fn.__get__(inst, type(inst)) if inst is not None else fn
    try:
        res = bound(event, **kw)
    except TypeError:
        try:
            res = bound(event)
        except TypeError:
            res = bound()
    if inspect.isasyncgen(res):
        chunks = []
        async for item in res:
            chunks.append(item)
        res = chunks
    elif asyncio.iscoroutine(res):
        res = await res
    items = res if isinstance(res, (list, tuple)) else [res]
    for item in items:
        if item is None:
            continue
        if isinstance(item, MessageChain):
            text = item.get_plain_text()
            if text:
                await ctx.reply(text)
        elif isinstance(item, (str, int, float)):
            await ctx.reply(str(item))
        else:
            try:
                await ctx.reply(str(item))
            except Exception:
                pass
    result = event.get_result()
    if result is not None:
        text = result.get_plain_text() if isinstance(result, MessageChain) else str(result)
        if text:
            await ctx.reply(text)
