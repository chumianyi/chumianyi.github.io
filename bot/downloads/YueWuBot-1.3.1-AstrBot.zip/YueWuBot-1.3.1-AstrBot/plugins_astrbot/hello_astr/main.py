from astrbot.api.event import filter, AstrMessageEvent
from astrbot.api.star import Star, register, Context


@register("astrbot_hello", "YueWu", "AstrBot 兼容示例", "1.0.0")
class HelloStar(Star):
    def __init__(self, context):
        super().__init__(context)

    @filter.command("astrhi")
    async def astrhi(self, event):
        yield event.plain_result("AstrBot 插件跑起来了，发送者 " + event.get_sender_id())

    @filter.command("astrping")
    async def astrping(self, event):
        return event.plain_result("pong from astrbot")
